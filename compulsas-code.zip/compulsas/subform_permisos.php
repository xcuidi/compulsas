<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');
// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
		<!--SELECT 2 -->
		<link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/select2/css/s2-docs.css">
		<!--END SELECT 2 -->
<body>

	<?php
 $query_menup="Select
    mnu.nombre As Menu,
    usuario.nombre as Usuario,
    perfil.id_pagina,
    perfil.nuevo,
    perfil.modificar,
    perfil.eliminar,
    perfil.excel,
    perfil.id_perfil
From
    perfil left Join
    mnu On mnu.id_mnu = perfil.id_mnu Left Join
    usuario On usuario.id_usuario = perfil.id_usuario
   where 
  perfil.id_pagina=".$_SESSION['Tempo_Pagina']."
ORDER BY
  mnu.nombre,
  perfil.id_pagina desc";
		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		
		$lm->primary_form=false; // Indicamos que no es un formulario principal
		
		// create LM object, pass in PDO connection
		//$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'perfil';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_perfil';
	
	if ($_SESSION['SesGrupo']==1) {
		$lm->puede_agregar=true;
		$lm->puede_borrar=true;
		$lm->puede_editar=true;
		$lm->puede_exportar=true;
	} else {
			if(substr($_SESSION['SesPermisos'],0,1)!="S") $lm->puede_agregar=false;
		if(substr($_SESSION['SesPermisos'],1,1)!="S") $lm->puede_editar=false;		
		if(substr($_SESSION['SesPermisos'],2,1)!="S") $lm->puede_borrar=false;
		if(substr($_SESSION['SesPermisos'],6,1)!="S") $lm->puede_exportar=false;
		
	}
	$lm->timezone='Mexico/General';
$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=15;
	
	
$lm->grid_input_control['nuevo'] = '--checkbox';
$lm->grid_input_control['modificar'] = '--checkbox';
$lm->grid_input_control['eliminar'] = '--checkbox';
$lm->grid_input_control['excel'] = '--checkbox';


$lm->form_input_control['nuevo'] = '--checkbox';
$lm->form_input_control['modificar'] = '--checkbox';
$lm->form_input_control['eliminar'] = '--checkbox';
$lm->form_input_control['excel'] = '--checkbox';

$lm->form_input_control['vista'] = '--checkbox';
$lm->form_input_control['buscar'] = '--checkbox';
$lm->form_input_control['html'] = '--checkbox';


//	$lm->grid_input_control['vista'] = "SELECT   'S' as opcion, 'S' as decrip UNION SELECT   'N' as opcion, 'N' as decrip ; --select"; 
//	$lm->grid_input_control['buscar'] = "SELECT   'S' as opcion, 'S' as decrip  UNION SELECT   'N' as opcion, 'N' as decrip ; --select";



     $lm->form_input_control['id_mnu_detp'] = "SELECT
  id_mnu_detp, etiqueta from
mnu_detp where 1
  order by etiqueta ; --select"; 
  $lm->form_default_value['activo']=1;
   $lm->form_default_value['nuevo']=0;
   $lm->form_default_value['modificar']=0;
    $lm->form_default_value['eliminar']=0;
	 $lm->form_default_value['vista']=0;
	  $lm->form_default_value['buscar']=0;
	   $lm->form_default_value['html']=0;
	    $lm->form_default_value['excel']=0;
		  $lm->form_default_value['id_pagina']=$_SESSION['Tempo_Pagina'];
  
  $lm->form_input_control['activo'] = '--checkbox';
    $lm->grid_input_control['activo'] = '--checkbox';
  
    $lm->grid_input_control['id_pagina'] = "SELECT
  id_pagina, concat(nombre, ' | ',pagina) as nombre from
 pagina
  order by nombre ; --select";  
  
      $lm->form_input_control['id_pagina'] = "SELECT
  id_pagina, concat(nombre, ' | ',pagina) as nombre from
 pagina
  order by nombre ; --select";  
  
		$lm->form_input_control['id_mnu'] = "SELECT
  id_mnu, nombre from
  mnu where 1
  order by nombre ; --select";
  //''''''''''''	
		// optional, make friendly names for fields
		
	$lm->rename['id_usuario'] = 'Usuario';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		
		$lm->form_input_control['id_mnu_detp'] = "SELECT
  mnu_detp.id_mnu_detp,
  
  Concat(mnu.nombre,' > ',mnu_detp.id_mnu_detp, ' - ', mnu_detp.etiqueta) AS c2
FROM
  mnu_detp
  INNER JOIN mnu ON mnu.id_mnu = mnu_detp.id_mnu
ORDER BY
  mnu.id_mnu, mnu_detp.orden_menu, mnu_detp.etiqueta; --select";
		

	$lm->form_input_control['id_pagina'] = "SELECT
  pagina.id_pagina,
  Concat(pagina.nombre, ' | ', pagina.pagina) AS c2
FROM
  pagina order by pagina.nombre; --select";
  
$lm->form_input_control['id_usuario'] = "SELECT
  usuario.id_usuario,
  usuario.nombre
FROM
  usuario order by usuario.nombre and usuario.usuario_activo=1; --select2";	  
		
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid
		
		//$lm->grid_show_search_box = true;
		
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		
	  $lm->form_sql = 'select id_perfil, id_mnu,  id_usuario,id_pagina from perfil where id_perfil = :id_perfil';
	$lm->form_sql_param = array(":id_perfil" => @$_REQUEST['id_perfil']); 
		$lm->grid_sql = $query_menup;
	//	echo "R: ",$_SESSION['Where_Region']," D: ",$_SESSION['Where_Diocesis']," S: ", $_SESSION['Where_Sector'], " ROL: ", $_SESSION['Where_Rol'], " N: ",$_SESSION['Where_Nivel'],"<br>";
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
			
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	//	$lm->form_default_value['condicion']=array(' where 1' );
		
		
		// use the lm controller
		$lm->run();
//}
	
								
	
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama?o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
?>
<table width="53%" border="0" cellspacing="3" class="bordered" align="center">
  <tr>
    <th colspan="2"><?php imprimir($recordset["lm_accion"],60);
			?></th>
  </tr>
  <tr>
    <td>Menu Padre </td>
    <td><?php imprimir($recordset["id_mnu"],20);
			?></td>
  </tr>
  <tr>
    <td>Usuario </td>
    <td><?php imprimir($recordset["id_usuario"],20);
			?></td>
  </tr>  
  <tr>
    <td width="166">Opci&oacute;n</td>
    <td width="398"><?php imprimir($recordset["id_pagina"],20);
			?></td>
  </tr>
  <tr>
    <td>Activo</td>
    <td><?php imprimir($recordset["activo"],80);
			?></td>
  </tr>
</table>
 <?php
} // fin plantilla
?>
<script>
<?php echo $JavaScript; ?>
</script>
 <script src="assets/libs/jquery/dist/jquery.min.js"></script>
	<!--SELECT 2 CSS / JS-->
	<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
		$('.js-example-placeholder-single').select2({
		placeholder: "Buscar y seleccionar...",
		width: '50%',
   	 	allowClear: true });
	});
	</script>
	<!--END SELECT 2 CCS / JS-->

	
    </body>

    </html>