<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

			<!--SELECT 2 -->
		<link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/select2/css/s2-docs.css">
		<!--END SELECT 2 -->
<body>
<h4>Reportes de ingresos 5 al millar SEFIN</h4>

	<?php
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
	//	$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
	

//ACTUALIZAMOS LAS FECHAS DE TEXTO A DATE EN LOS CAMPOS FECHA NULOS
$lm->query("update tabla_siox set fecha_pago=fecha_pago_txt where fecha_pago is null")	;
$lm->query("update tabla_siox set importe_total=importe_total_txt where importe_total is null")	;
$lm->query("update tabla_siox set importe_clave=importe_clave_txt where importe_clave is null")	;
		// table name for updates, inserts and deletes
		$lm->table = 'tabla_siox';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_siox';
//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario);
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/

$lm->grid_limit = 10;

$query_tablas="Select
	tabla_siox.estatus_linea,
	tabla_siox.folio,
	tabla_siox.razon_social,
    tabla_siox.fecha_pago,
    tabla_siox.importe_clave,
      tabla_siox.ramo_fuente,
    concat_ws(' | ',catalogo_ur.clave_ur,catalogo_ur.nombre_ur) as UR,
    tabla_siox.id_siox
From
    tabla_siox Left Join
    catalogo_ur On catalogo_ur.id_ur = tabla_siox.id_ur
	where 1 $condicion";

$lm->grid_area_cols_size=40;
$lm->form_text_input_size=150;
$lm->grid_area_rows_size=5;

$lm->form_input_control['razon_social']="--readonly";
$lm->form_input_control['id_ur']="Select
    catalogo_ur.id_ur,
    concat_ws('| ',catalogo_ur.clave_ur,
    catalogo_ur.nombre_ur,
    catalogo_ur.referencia) as Nombre
From
    catalogo_ur --select2";
	
$lm->form_input_control['fecha_pago']="--readonly";
$lm->form_input_control['folio']="--readonly";
$lm->form_input_control['ramo_fuente']="--readonly";
$lm->form_input_control['importe_clave']="--readonly";

	
$lm->form_sql="Select
    tabla_siox.razon_social,
	tabla_siox.id_ur,
	tabla_siox.folio,
   
	 tabla_siox.ramo_fuente,
    tabla_siox.importe_clave,
	tabla_siox.clc,
    tabla_siox.id_siox
From
    tabla_siox where id_siox = :id_siox";
		
		// optional, define input controls on the form
		//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';
// optional, define editable input controls on the grid
		//$lm->form_input_control['is_active'] = "select 1, 'Yes' union select 0, 'No' union select 2, 'Maybe'; --radio";
			

		$lm->grid_sql = $query_tablas;
		
	
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	
		// use the lm controller
		$lm->run();
//}

?>	

<script>
<?php echo $JavaScript; ?>
</script>
 <script src="assets/libs/jquery/dist/jquery.min.js"></script>
	<!--SELECT 2 CSS / JS-->
	<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
		$('.js-example-placeholder-single').select2({
		placeholder: "Buscar y seleccionar...",
   	 	allowClear: true });
	});
	</script>
	<!--END SELECT 2 CCS / JS-->

	
    </body>

    </html>