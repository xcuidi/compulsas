<?php
	 session_start();  
	  header('Cache-Control: no-cache');
	  header('Pragma: no-cache');
		include ("./utilerias/objetos.php");  // para p�ginas con phpgrid
		include ("./utilerias/funciones.php"); 
		include ("./utilerias/conexion.php"); 
// LAZYMOFO
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
require_once("./utilerias/connect.php");
include('./utilerias/lazy_mofo.php');
// FIN LAZYMOFO 
 	 if (!isset($_SESSION['Usuario']) ){
		  session_destroy(); // destruyo la sesi�n  
		  header("Location: expired.php"); 
      }
		$displayMNU=true;


?>
<!DOCTYPE html>
<html>


<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="./css/stylesheet.css">
	<link rel='stylesheet' type='text/css' href='utilerias/style.css'>

<meta http-equiv="Content-Type" content="text/html; charset='UTF-8'">


</head>
<body>
<?php   
//VERIFICAREMOS QUE LA ACTUALIZACION DE MOMENTOS FUERTES Y CAPACITACIONES NO SE HAYA APLICADO EN ESTA SESION
if (!isset($_SESSION['Filtro_Reporte']) ) $_SESSION['Filtro_Reporte']=0;
//

if (isset($_POST["entidad"])) {
	
	$entidad=$_POST["entidad"];
	
    }   
if (isset($_POST["id_ur"])) {
	
	$entidad=$_POST["id_ur"];
	
    }   
				

	
?>
	<br>
<form method="post" action="<?=$_SERVER['PHP_SELF']?>" id="frmDatos" class="bordered">
<table width="100%" border="0" cellspacing="3">
  <tr>
    <th scope="row"> <?php echo $_SESSION['var_sql_nombrereporte'] ?></th>
    <td width="11%" scope="row"><a class='btn btn-warning' href="reportes.php" title="Otros reportes"><strong>Otros Reportes</strong></a></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="3" class="datacell">
  <tr>
    <td scope="row"><?php echo $_SESSION['var_sql_sugerencia']?></td>
    </tr>
</table>
</form>
<?php 
  
 $query_reporte= $_SESSION['var_sql_query']."  ".$_SESSION['var_sql_condicion']." ".$_SESSION['var_sql_grupo']."  order by ".$_SESSION['var_sql_orden'];
								

												
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		$lm = new lazy_mofo($dbh); 
		
		
	
		// table name for updates, inserts and deletes
		$lm->table = $_SESSION['var_sql_tabla'];
		
		 $lm->return_to_edit_after_insert = false;
	 $lm->return_to_edit_after_update = false;
		// identity / primary key for table
		$lm->identity_name = $_SESSION['var_sql_id'];
	//	$lm->identity_name = 'id_cat_servicios';
		
				$lm->puede_exportar=false;
	
		$lm->puede_agregar=false;
		$lm->puede_borrar=false;
		$lm->puede_editar=false;
		$lm->puede_exportar=true;
		
	
		$lm->date_out = 'd/m/Y';
		// optional, define editable input controls on the grid
		
			
		if ($_SESSION['var_sql_condicion']!="") $lm->grid_show_search_box = true;
		
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		$lm->grid_sql = $query_reporte;
	if ($_SESSION['SesGrupo']==1) echo "SOLO VISIBLE PARA SYSADMIN <br>", $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';

		$lm->run();


?>							
								

</body>
</html>

