<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
<body>
<h4>Reportes</h4>

<?php
try {
  $dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
}
catch(PDOException $e) {
  die('pdo connection error: ' . $e->getMessage());
}




// create LM object, pass in PDO connection
$lm = new lazy_mofo($dbh); 

function llenarcombo($query="",$valor=0,$descrip="") {
  global $dbh;
  $combo="<option value=0>Buscar..</option>";
   foreach($dbh->query($query) as $row) {
    $combo.= "<option value=".$row[$valor].">".$row[$descrip]."</option>";
      }
    return $combo;
}

?>
 <form action="identificar_bloque.php"  id="miformulario3" method="get">
<table style='width: 100%;' id='example_x' class='table table-hover table-striped table-bordered'>
  <tr>
    <th colspan="2">REPORTES GENERALES </th>
  </tr>
  <tr>
    <td width="19%">Seleccione Entidad concentradora </td>
  
    <td width="81%">
     
      <select value='' name="entidad" id="entidad" class='lm_search_input' placeholder='Seleccionar'> <?php
          print llenarcombo("Select
    Replace(tabla_finanzas.entidad_concentradora, ' ', '*') As entidad_concentradora,
    Concat_Ws(' |', tabla_finanzas.entidad_concentradora, Count(tabla_finanzas.entidad_concentradora)) As registros
From
    tabla_finanzas
Where
    tabla_finanzas.id_ur Is Null
Group By
    tabla_finanzas.entidad_concentradora
Order By
    Count(tabla_finanzas.entidad_concentradora) Desc","entidad_concentradora","registros"); ?>  </select>
	</td>
	</tr>
	<tr>
	<td width="19%">Seleccione valor del catálogo </td>
 <td width="81%">	
 <select value='' name="id_ur" id="id_ur" class='lm_search_input' placeholder='Seleccionar'> <?php
          print llenarcombo("Select
    catalogo_ur.id_ur,
    concat_ws('| ',catalogo_ur.nombre_ur,catalogo_ur.clave_ur,
    catalogo_ur.referencia) as Nombre
From
    catalogo_ur order by catalogo_ur.nombre_ur","id_ur","Nombre"); ?>  </select>
	
      <input name="submit172" type="submit" value="Ejecutar" />
          </td>
  </tr>
</table>
</form>
</body>
	<!--SELECT 2 CSS / JS-->
	<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
		$('.js-example-placeholder-single').select2({
		placeholder: "Buscar y seleccionar...",
		width: '50%',
   	 	allowClear: true });
	});
	</script>
	<!--END SELECT 2 CCS / JS-->
</html>