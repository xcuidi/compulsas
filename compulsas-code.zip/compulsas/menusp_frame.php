<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

$filtro_menu= " and mnu_detp.id_mnu= ".$_SESSION['TEMPO_MENU'];

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>




<body>
                  
                              <h4>Menus desplegables</h4>
	<?php
 
		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
		$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO

$lm->primary_form=false; // Indicamos que no es un formulario principal
		
		// table name for updates, inserts and deletes
		$lm->table = 'mnu_detp';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_mnu_detp';
	$lm->timezone='Mexico/General';
$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=15;
		
		// optional, make friendly names for fields
		
	//	$lm->rename['usuario_activo'] = 'Activo';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		
		$lm->form_input_control['id_mnu'] = "SELECT
  mnu.id_mnu as c1,
  concat(id_mnu, ' | ', mnu.nombre) as c2
FROM
  mnu; --select";
		
		$lm->grid_input_control['activo'] = "--checkbox";
		
	
		
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid

// define our own search form with two inputs instead of the default one
////	<input type='text' name='new_search_1' value='$new_search_1' size='20' class='lm_search_input' placeholder='Diocesis'>
		
$query_menup="SELECT
  mnu_detp.orden_menu AS orden,
  concat(mnu_detp.id_mnu_detp,' | ',mnu_detp.etiqueta) AS `Menu Padre`,
   mnu_detp.icono,
(select count(*) from mnu_deth where mnu_detp.id_mnu_detp=mnu_deth.id_mnu_detp and mnu_deth.activo=1) as Opciones_Activas,
(select count(*) from mnu_deth where mnu_detp.id_mnu_detp=mnu_deth.id_mnu_detp and mnu_deth.activo is null) as Opciones_Inactivas,
  mnu_detp.activo,
  mnu_detp.id_mnu_detp
FROM
  mnu
  INNER JOIN mnu_detp ON mnu_detp.id_mnu = mnu.id_mnu
  where 1 $filtro_menu
   order by mnu.id_mnu, mnu_detp.orden_menu";		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		
		
		$lm->grid_sql = $query_menup;
	//	echo "R: ",$_SESSION['Where_Region']," D: ",$_SESSION['Where_Diocesis']," S: ", $_SESSION['Where_Sector'], " ROL: ", $_SESSION['Where_Rol'], " N: ",$_SESSION['Where_Nivel'],"<br>";
	
//		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
		$lm->form_sql = "SELECT
  mnu_detp.etiqueta,
  mnu_detp.orden_menu,
  mnu_detp.id_mnu_detp,
  mnu_detp.icono,
  mnu_detp.activo,
  mnu_detp.id_mnu
FROM
  mnu_detp
WHERE
  mnu_detp.id_mnu_detp = :id_mnu_detp";
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
		$lm->form_default_value['id_mnu']=$_SESSION['TEMPO_MENU'];
		
//			echo $lm->grid_sql;
		// use the lm controller
		$lm->run();
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama�o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
global $lm;
$editable=true;
$nuevo_registro=true;
$activa='active';
if ($recordset["lm_accion"]!="Editar") $editable=false;

	$parametro=$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	$_SESSION['TEMPO_MENUP']=$parametro;
 ?>
    <div class="card-block">
                <ul class="nav nav-tabs" role="tablist">
				
                    <li class="nav-item ">
                        <a class="btn btn-sm btn-inverse-info waves-effect waves-light" data-toggle="tab" href="#tab0" role="tab">Menu</a>
                    </li>
							
                    <li class="nav-item ">
						<a class='btn btn-sm btn-inverse-info waves-effect waves-light' data-toggle='modal' data-target='#openModal2' ><span>Opciones</span></a>
                    </li>			
					
                </ul>  
                <div class="tab-content">
					<div class="tab-pane active" id="tab0" role="tabpanel">
						<div class="card-block">

							<div class="row">
							
								   <!--Horizontal Form starts-->
								   <div class="col-lg-6">


										<table>
										  <tr>
											<th colspan="2"><?php imprimir($recordset["lm_accion"],60);
													?></th>
										  </tr>
										  <tr>
											<td>Menu General </td>
											<td><?php imprimir($recordset["id_mnu"],20);
													?></td>
										  </tr>
										  <tr>
											<td width="166">Nombre del Menú </td>
											<td width="398"><?php imprimir($recordset["etiqueta"],20);
													?></td>
										  </tr>
										  <tr>
											<td>Orden</td>
											<td><?php imprimir($recordset["orden_menu"],80);
													?></td>
										  </tr>
										  <tr>
											<td>icono</td>
											<td><?php imprimir($recordset["icono"],80);
													?></td>
										  </tr>
										  <tr>
											<td>Iconos</td>
											<td><a href="https://www.bootstrapicons.com/index.htm?iconset=fontawesome&version=4.0.3" target="_blank"> https://www.bootstrapicons.com/index.htm?iconset=fontawesome&version=4.0.3</a></td>
										  </tr>
										</table>
									 </div>
								  
			  
							</div> <!--row-->	
						</div>
					</div>  

				</div>		
	</div>
	<div class="modal fade modal-flex" id="openModal2" tabindex="-1" role="dialog">

    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
				<iframe src="menush_modal.php?id_mnu= <?=$parametro; ?>" style="border: 1" width="100%" height="400px" frameborder="1" scrolling="yes"></iframe>
            </div>

        </div>

    </div>

	</div>	
				

<?php

} // fin plantilla
?>

</body>
</html>