<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

    <body>
<h5>Menus Generales</h5>

<?php
try {
    $dbh = new PDO("mysql:host=" . LM_HOSTNAME . ";dbname=" . LM_NAME . ";charset=utf8", LM_USERNAME, LM_PASSWORD);
}
catch(PDOException $e) {
    die('pdo connection error: ' . $e->getMessage());
}
// create LM object, pass in PDO connection
$lm = new lazy_mofo($dbh);

$lm->date_out = 'd/m/Y';
$lm->datetime_out = 'd/m/Y h:i A';

$lm->table = 'mnu';
$lm->identity_name = 'id_mnu';

$condicion = "";
//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario,'M');
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/
// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
$lm->grid_sql = "SELECT
mnu.id_mnu as ID,
  mnu.nombre,
  (select count(*) from mnu_detp where mnu.id_mnu=mnu_detp.id_mnu and mnu_detp.activo=1) as Menus_Activos,
   (select count(*) from mnu_detp where mnu.id_mnu=mnu_detp.id_mnu and mnu_detp.activo is null) as Menus_inactivos,
  mnu.id_mnu
FROM
  mnu where 1 $condicion";

		$lm->form_sql = "SELECT
  mnu.nombre,
  mnu.id_mnu
FROM
  mnu  where id_mnu = :id_mnu ";

$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name];

$lm->run();
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama�o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
global $lm;
$editable=true;
$nuevo_registro=true;
$activa='active';
if ($recordset["lm_accion"]!="Editar") $editable=false;

	$parametro=$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
$_SESSION['TEMPO_MENU']=$parametro;
 ?>
        <div class="card-block">
                <ul class="nav nav-tabs" role="tablist">
				
                    <li class="nav-item ">
                        <a class="btn btn-sm btn-inverse-info waves-effect waves-light" data-toggle="tab" href="#tab0" role="tab">Grupo Menu</a>
                    </li>
							
                    <li class="nav-item ">
                        <a class="btn btn-sm btn-inverse-info waves-effect waves-light" data-toggle="tab" href="#tab1" role="tab">Menus (Frame)</a>
                    </li>			
					
                </ul>  
                <div class="tab-content">
					<div class="tab-pane active" id="tab0" role="tabpanel">
						<div class="card-block">

							<div class="row">
							
								   <!--Horizontal Form starts-->
								   <div class="col-lg-6">


										<div class="card card-block card-inner-shadow global-cards">

							 	 
											  <div class="form-group row">
												 <label class="col-md-2 col-form-label form-control-label">Nombre Grupo Menu</label>
												 <div class="col-md-10">
												   <?php imprimir($recordset["nombre"],80); ?>
												 </div>
											  </div>	

											  
									  

										</div>
									 </div>
								  
			  
							</div> <!--row-->	
						</div>
					</div>  
					<div class="tab-pane" id="tab1" role="tabpanel">
						<div class="card-block">

							<div class="row">
                            <?php  if($editable) { ?>   
		                        
								<iframe src="menusp_frame.php?id_mnu= <?=$parametro; ?>" style="border: 1" width="100%" height="650px" frameborder="1" scrolling="yes"></iframe>
	                            
  
  	                        <?php } ?> 							
								   
							</div>
						</div>  					
							
					</div>
		</div>										
						

<?php

} // fin plantilla
?>


	
</body>
</html>