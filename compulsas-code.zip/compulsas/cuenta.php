<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');
?>

<!doctype html>
<html lang="es">

<head>
<!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
     <![endif]-->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/main.css">
<script type="text/javascript" src="bower_components/tether/dist/js/tether.min.js"></script>

</head>
<body>
<div class="card-header">
                <h3 class="card-title">CAMBIO DE CLAVE DE ACCESO</h3>
</div>
<?php
									
											try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		$lm = new lazy_mofo($dbh); 
		
		// create LM object, pass in PDO connection
		
		// table name for updates, inserts and deletes
		$lm->table = 'usuario';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = false;
		// identity / primary key for table
		$lm->identity_name = 'id_usuario';
				$lm->puede_exportar=false;
	
		$lm->puede_agregar=false;
		$lm->puede_borrar=false;
		$lm->puede_editar=true;
		
		// optional, make friendly names for fields
		
		//$lm->rename['nombres'] = 'Nombres';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		
		
		// optional, define input controls on the form
			
		
		$lm->date_out = 'd/m/Y';
		// optional, define editable input controls on the grid
		
//	$lm->grid_show_search_box = true;
		
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		
		
		$lm->grid_sql = "SELECT
  usuario.nombre,
  usuario.usuario,
  usuario.correo,
  usuario.id_usuario
FROM
  usuario
WHERE
  usuario.usuario_activo = 1 and id_usuario=".$_SESSION['SesIdUsuario'];	//	echo "R: ",$_SESSION['Where_Region']," D: ",$_SESSION['Where_Diocesis']," S: ", $_SESSION['Where_Sector'], " ROL: ", $_SESSION['Where_Rol'], " N: ",$_SESSION['Where_Nivel'],"<br>";
  
$lm->form_sql = " SELECT
  usuario.nombre,
  usuario.correo,
  usuario.clave,
   usuario.id_usuario
FROM
  usuario
WHERE
id_usuario= :id_usuario";  
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
$lm->rename['correo'] = 'Correo Electronico';
$lm->rename['usuario'] = 'Nombre de usuario ';
$lm->rename['clave'] = 'Clave de acceso';
$lm->on_update_user_function= 'update_modificado';		
function update_modificado(){
		global $lm;	
	date_default_timezone_set('Mexico/General');
	
		$sql_param = array(':id_mrf' => $_POST['id_mrf']);
	$instruccion= "El usuario con ID: ".$_SESSION['SesIdUsuario']." de nombre ".$_SESSION['Nombre_Usuario']." ha actualizado su clave de acceso";
	$sql_bitacora="insert into bitacora (id_bitacora, movimiento, observaciones, fecha, id_usuario) values (0,'Cambio de Password','".$instruccion."',now(),".$_SESSION['SesIdUsuario'].")";				 
	$lm->query($sql_bitacora, $sql_param);		
	
}
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
	
		
		
		// use the lm controller
		$lm->run();														
									?>
	
</body>
</html>