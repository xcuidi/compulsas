<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

 $buscar_por = key_exists('buscar', $_GET) ? $_GET['buscar'] : '0'	;
 if ($buscar_por!='0') $_SESSION['Tempo_Buscar']=$buscar_por;
 
// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML


?>

<body>

	<?php
 
		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		$lm = new lazy_mofo($dbh); 
		$lm->primary_form=false; // Indicamos que no es un formulario principal
	

//$Where_filtros['Filtro'] 
		
//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario);
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/		
		// table name for updates, inserts and deletes
		$lm->table = 'tabla_siox';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_siox';

		
		$id_ur=$_SESSION['Tempo_UR'];
		$rfc_id=$_SESSION['Tempo_RFC'];
		$oficio_autorizacion=$_SESSION['Tempo_oficio_autorizacion'];
		
		if ($_SESSION['Tempo_Buscar']=='rfc') $sql_buscar_por=" and tabla_siox.rfc = '$rfc_id'";
		if ($_SESSION['Tempo_Buscar']=='ur')$sql_buscar_por=" and tabla_siox.id_ur = $id_ur";
		if ($_SESSION['Tempo_Buscar']=='oa')$sql_buscar_por=" and tabla_siox.num_oficio_autorizacion = '$oficio_autorizacion'";
		
			$query_paginas="Select
	tabla_siox.estatus_linea,
	tabla_siox.folio,
	tabla_siox.razon_social,
	tabla_siox.descripcion_pago,
    tabla_siox.fecha_pago,
	format(tabla_siox.importe_total,2) as importe_total,
    format(tabla_siox.importe_clave,2) as importe_clave,
     tabla_siox.ramo_fuente,
	 tabla_siox.num_oficio_autorizacion,
	 tabla_siox.fuente_financiamiento,
    tabla_siox.id_siox
From
    tabla_siox
Where 1 $condicion  $sql_buscar_por";
	
$lm->grid_area_cols_size=20;
$lm->grid_area_rows_size=5;

	
	
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid
		

		
		
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		
		
		$lm->grid_sql = $query_paginas;

		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	//	$lm->form_default_value['condicion']=array(' where 1' );
		
	//	echo $lm->grid_sql;
	//	echo "<br>",$_SESSION['Tempo_oficio_autorizacion'];
		// use the lm controller
		$lm->run();
//}

?>

<script>
<?php echo $JavaScript; ?>
</script>
 
</body>
</html>
