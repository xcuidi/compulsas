<?php  
//define('K_TCPDF_CALLS_IN_HTML', true);

require_once("tcpdf/tcpdf.php");    
require_once("funciones.php");
include("../utilerias/connect.php");
require("../utilerias/NumeroALetras.php");
//include("../utilerias/lazy_mofo.php");

 $id_operacion = key_exists('id_operacion', $_GET) ? $_GET['id_operacion'] : 0; 

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
	//		var_dump($dbh);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}

		// create LM object, pass in PDO connection

		
//$sql = new sql();

	$datos="Select
	pagares.id_pagare,
	pagares.id_operacion,
    pagares.numero_pagare,
    day(operaciones.fecha_operacion) as dia_op,
	month(operaciones.fecha_operacion) as mes_op,
	year(operaciones.fecha_operacion) as anio_op,
    pagares.fecha_pagare,
	day(pagares.fecha_pagare) as dia_pago,
	month(pagares.fecha_pagare) as mes_pago,
	year(pagares.fecha_pagare) as anio_pago,
    format(pagares.importe,2) as importe,
	 pagares.importe as importe2,
    Concat_Ws(' ', cliente.apellidop, cliente.apellidom, cliente.nombre) As nombre_cliente,
    Concat_Ws('. ', cliente.domicilio, cliente.colonia) As dom_colonia,
    concat_ws('. ',cliente.municipio,'CP', cliente.cp) as mpio,
    (Select
         count(*)
     From
         pagares
     Where
         pagares.id_operacion = $id_operacion) As ultimo
From
    pagares Inner Join
    operaciones On operaciones.id_operacion = pagares.id_operacion Inner Join
    cliente On cliente.id_cliente = pagares.id_cliente
	
	where pagares.id_operacion=$id_operacion";

//number_format($calculo[0]['Bruto'], 2, '.', ',')



//print_r($datos);
//print_r($diocesis);
//die();

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, 'mm', 'LEGAL', true, 'UTF-8', false);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
$pdf->setFontSubsetting(false);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->SetMargins(15, 5);
$pdf->SetAutoPageBreak(false);

	$style = array(
		'border' => 0,
		'vpadding' => 0,
		'hpadding' => 0,
		'fgcolor' => array(0,0,0),
		'bgcolor' => false, 
		'module_width' => 1, 
		'module_height' => 1 
	);
	
		$fondo = 'img_pagare_hr.jpg';
	//
  $fontname = TCPDF_FONTS::addTTFfont('tcpdf/fonts/Univia_W03_Regular.ttf');
	 $pdf->SetFont($fontname, '', 9);
$consecutivo=0;
$numeracion=0;
$linea='-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -';
//for ($recordset=0;count($datos); $recordset++) {	

$style = array(
    'border' => 0,
    'vpadding' => 1,
    'hpadding' => 1,
    'fgcolor' => array(0,0,0),
    'bgcolor' => array(255,255,255), 
    'module_width' => 1, 
    'module_height' => 1 
);


foreach($conn->query($datos) as $registro) {
	 $fontname = TCPDF_FONTS::addTTFfont('tcpdf/fonts/Univia_W03_Regular.ttf');
	  $pdf->SetFont($fontname, '', 10);
	//$registro = $datos[$recordset];
	$consecutivo++;
	$numeracion++;
	if ($consecutivo==4)  {
		$consecutivo=1;

	}


switch($consecutivo) {
case 1:		
	$pdf->AddPage('P','LETTER');
	$x = 10;
	$y = 10;	
	$z = 0;
	break;
	
case 2:
// $pdf->AddPage();
	$x = 10;
	$y = 100;
	$z = 92;	
	break;

case 3:
// $pdf->AddPage();
	$x = 10;
	$y = 192;	
	$z = 184;
	break;

}
	$qr='P-'.$registro['id_pagare'].'-'.$registro['id_operacion'];
	
	$pdf->Image($fondo, $x, $y, 198, 80, '', '', '', true);
	$pdf->write2DBarcode($qr, 'QRCODE,L', $x+87, $y+55, 22, 22, $style);
	if($z>0) { $pdf->SetXY($x, $z); $pdf->Cell(200, 0,  $linea, 0, 0, 'C', 0, '', 0); }
	$pdf->SetXY($x+15, $y+10); $pdf->Cell(5, 0, $registro['numero_pagare']." / ".$registro['ultimo'], 0, 0, 'C', 0, '', 0);	
	$pdf->SetXY($x+60, $y+10); $pdf->Cell(5, 0, "OAXACA DE JUAREZ, OAXACA", 0, 0, 'C', 0, '', 0);	
	$pdf->SetXY($x+105, $y+10); $pdf->Cell(5, 0,  $registro['dia_op'], 0, 0, 'C', 0, '', 0);
	$pdf->SetXY($x+125, $y+10); $pdf->Cell(5, 0,  nombre_mes($registro['mes_op']), 0, 0, 'C', 0, '', 0);
	$pdf->SetXY($x+153, $y+10); $pdf->Cell(5, 0,  $registro['anio_op'], 0, 0, 'C', 0, '', 0);
	$pdf->SetXY($x+175, $y+10); $pdf->Cell(5, 0,  $registro['importe'], 0, 0, 'C', 0, '', 0);

	$pdf->SetXY($x+50, $y+21); $pdf->Cell(5, 0,  "JAIME NOÉ CASTELLANOS GÓMEZ", 0, 0, 'C', 0, '', 0);
	$pdf->SetXY($x+127, $y+21); $pdf->Cell(5, 0,  $registro['dia_pago'], 0, 0, 'C', 0, '', 0);
	$pdf->SetXY($x+148, $y+21); $pdf->Cell(5, 0,  nombre_mes($registro['mes_pago']), 0, 0, 'C', 0, '', 0);
	$pdf->SetXY($x+187, $y+21); $pdf->Cell(5, 0,  $registro['anio_pago'], 0, 0, 'C', 0, '', 0);
	
	$pdf->SetXY($x+100, $y+28); $pdf->Cell(5, 0,  NumeroALetras::convertir(round($registro['importe2'],2), 'PESOS', 'CENTAVOS'), 0, 0, 'C', 0, '', 0);
	
	$pdf->SetXY($x+114, $y+35); $pdf->Cell(5, 0,  "1", 0, 0, 'C', 0, '', 0);
	$pdf->SetXY($x+126, $y+35); $pdf->Cell(5, 0,  $registro['ultimo'], 0, 0, 'C', 0, '', 0);
	$pdf->SetFont($fontname, '', 7);
	$pdf->SetXY($x+20, $y+55); $pdf->MultiCell(70, 0, $registro['nombre_cliente'], 0,'L', 0, 1);
	//$pdf->SetXY($x+20, $y+57); $pdf->Cell(5, 0, $registro['nombre_cliente'] , 0, 0, 'L', 0, '', 0);	
	$pdf->SetXY($x+20, $y+62); $pdf->MultiCell(70, 0, $registro['dom_colonia'], 0,'L', 0, 1);
	//$pdf->Cell(5, 0, $registro['dom_colonia'] , 0, 0, 'L', 0, '', 0);
	$pdf->SetXY($x+20, $y+71); $pdf->Cell(5, 0, $registro['mpio'] , 0, 0, 'L', 0, '', 0);	
	$pdf->setPageMark();
	
	
}
$pdf->Output('pagares_'.$id_operacion.'.pdf', 'I');
