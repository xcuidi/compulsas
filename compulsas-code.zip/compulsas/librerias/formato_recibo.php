<?php  
//define('K_TCPDF_CALLS_IN_HTML', true);

require_once("tcpdf/tcpdf.php");    
require_once("funciones.php");
include("../utilerias/connect.php");
require("../utilerias/NumeroALetras.php");
//include("../utilerias/lazy_mofo.php");

 $id_arrendamiento = key_exists('id_arrendamiento', $_GET) ? $_GET['id_arrendamiento'] : 0; 

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
	//		var_dump($dbh);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}

		// create LM object, pass in PDO connection

		
//$sql = new sql();

	$datos="Select
    recibos.id_recibo,
    recibos.id_arrendamiento,
    recibos.numero_recibo,
    tipo_inmueble.tipo,
    Concat_Ws(' ',   inmueble.domicilio,inmueble.num_domicilio, inmueble.colonia,inmueble.municipio) As ubicacion,
    Day(arrendamientos.fecha_contrato) As dia_op,
    Month(arrendamientos.fecha_contrato) As mes_op,
    Year(arrendamientos.fecha_contrato) As anio_op,
    recibos.fecha_recibo,
    Day(recibos.fecha_recibo) As dia_pago,
    Month(recibos.fecha_recibo) As mes_pago,
    Year(recibos.fecha_recibo) As anio_pago,
    Format(recibos.importe, 2) As importe,
    recibos.importe As importe2,
    cliente.nombre As nombre_cliente,
    Concat_Ws(' ', cliente.apellidop, cliente.apellidom) As apellidos_cliente,
    Concat_Ws('. ', cliente.domicilio, cliente.colonia) As dom_colonia,
    Concat_Ws('. ', cliente.municipio, 'CP', cliente.cp) As mpio,
    (Select
         count(*)
     From
         recibos
     Where
         recibos.id_arrendamiento = $id_arrendamiento) As ultimo
From
    recibos Inner Join
    arrendamientos On arrendamientos.id_arrendamiento = recibos.id_arrendamiento Inner Join
    cliente On cliente.id_cliente = recibos.id_cliente Inner Join
    inmueble On inmueble.id_inmueble = recibos.id_inmueble Inner Join
    tipo_inmueble On inmueble.id_tipo = tipo_inmueble.id_tipo
	
	where recibos.id_arrendamiento=$id_arrendamiento";

//number_format($calculo[0]['Bruto'], 2, '.', ',')



//print_r($datos);
//print_r($diocesis);
//die();

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, 'mm', 'LEGAL', true, 'UTF-8', false);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
$pdf->setFontSubsetting(false);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->SetMargins(15, 5);
$pdf->SetAutoPageBreak(false);

	$style = array(
		'border' => 0,
		'vpadding' => 0,
		'hpadding' => 0,
		'fgcolor' => array(0,0,0),
		'bgcolor' => false, 
		'module_width' => 1, 
		'module_height' => 1 
	);
	
		$fondo = 'img_recibo_hr.jpg';
	//
  $fontname = TCPDF_FONTS::addTTFfont('tcpdf/fonts/Univia_W03_Regular.ttf');
	 $pdf->SetFont($fontname, '', 9);
$consecutivo=0;
$numeracion=0;
$linea='-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -';
//for ($recordset=0;count($datos); $recordset++) {	

$style = array(
    'border' => 0,
    'vpadding' => 1,
    'hpadding' => 1,
    'fgcolor' => array(0,0,0),
    'bgcolor' => array(255,255,255), 
    'module_width' => 1, 
    'module_height' => 1 
);


foreach($conn->query($datos) as $registro) {
	 $fontname = TCPDF_FONTS::addTTFfont('tcpdf/fonts/Univia_W03_Regular.ttf');
	  $pdf->SetFont($fontname, '', 9);
	//$registro = $datos[$recordset];
	$consecutivo++;
	$numeracion++;
	if ($consecutivo==4)  {
		$consecutivo=1;

	}


switch($consecutivo) {
case 1:		
	$pdf->AddPage('P','LETTER');
	$x = 10;
	$y = 10;	
	$z = 0;
	break;
	
case 2:
// $pdf->AddPage();
	$x = 10;
	$y = 100;
	$z = 92;	
	break;

case 3:
// $pdf->AddPage();
	$x = 10;
	$y = 192;	
	$z = 184;
	break;

}
	$qr='R-'.$registro['id_recibo'].'-'.$registro['id_arrendamiento'];
	
	$pdf->Image($fondo, $x, $y, 198, 80, '', '', '', true);
	$pdf->write2DBarcode($qr, 'QRCODE,L', $x+173, $y+33, 24, 24, $style);
	if($z>0) { $pdf->SetXY($x, $z); $pdf->Cell(200, 0,  $linea, 0, 0, 'C', 0, '', 0); }
	$pdf->SetXY($x+8, $y+8); $pdf->Cell(5, 0, $registro['numero_recibo']." / ".$registro['ultimo'], 0, 0, 'C', 0, '', 0);	
	$pdf->SetXY($x+120, $y+8); $pdf->Cell(5, 0, $registro['numero_recibo']." / ".$registro['ultimo'], 0, 0, 'C', 0, '', 0);		
//	$pdf->SetXY($x+60, $y+10); $pdf->Cell(5, 0, "OAXACA DE JUAREZ, OAXACA", 0, 0, 'C', 0, '', 0);	
//	$pdf->SetXY($x+105, $y+10); $pdf->Cell(5, 0,  $registro['dia_op'], 0, 0, 'C', 0, '', 0);
//	$pdf->SetXY($x+125, $y+10); $pdf->Cell(5, 0,  nombre_mes($registro['mes_op']), 0, 0, 'C', 0, '', 0);
//	$pdf->SetXY($x+153, $y+10); $pdf->Cell(5, 0,  $registro['anio_op'], 0, 0, 'C', 0, '', 0);
	$pdf->SetXY($x+42, $y+8); $pdf->Cell(5, 0,  $registro['importe'], 0, 0, 'L', 0, '', 0);
	$pdf->SetXY($x+175, $y+8); $pdf->Cell(5, 0,  $registro['importe'], 0, 0, 'C', 0, '', 0);	
	$pdf->SetFont($fontname, '', 7);
	
	$pdf->SetXY($x+15, $y+16); $pdf->MultiCell(70, 0, $registro['nombre_cliente'], 0,'L', 0, 1);
	$pdf->SetXY($x+15, $y+19); $pdf->MultiCell(70, 0, $registro['apellidos_cliente'], 0,'L', 0, 1);

	//$pdf->SetXY($x+90, $y+16); $pdf->MultiCell(70, 0, $registro['nombre_cliente'], 0,'L', 0, 1);
	$pdf->SetXY($x+80, $y+19); $pdf->MultiCell(70, 0, $registro['nombre_cliente']. " ".$registro['apellidos_cliente'], 0,'L', 0, 1);
	
	$pdf->SetXY($x+8, $y+42); $pdf->MultiCell(50, 0,"RENTA MENSUAL DE ". $registro['tipo']." CON UBICACIÓN EN ". $registro['ubicacion'], 0,'L', 0, 1);	

	$pdf->SetXY($x+8, $y+26); $pdf->MultiCell(50, 0,NumeroALetras::convertir(round($registro['importe2'],2), 'PESOS', 'CENTAVOS'), 0,'L', 0, 1);	

	
	$pdf->SetFont($fontname, '', 9);
	$pdf->SetXY($x+80, $y+42); $pdf->MultiCell(70, 0,"RENTA MENSUAL DE ". $registro['tipo']." CON UBICACIÓN EN ". $registro['ubicacion'], 0,'L', 0, 1);	

	
	$pdf->SetFont($fontname, '', 9);	
	$pdf->SetXY($x+120, $y+28); $pdf->Cell(5, 0,  NumeroALetras::convertir(round($registro['importe2'],2), 'PESOS', 'CENTAVOS'), 0, 0, 'C', 0, '', 0);

	
	$pdf->setPageMark();
	
	
}
$pdf->Output('recibos_'.$id_arrendamiento.'.pdf', 'I');
