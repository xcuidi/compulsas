<?php


function titulo($texto2) {
    $texto = mb_convert_case($texto2, MB_CASE_UPPER, 'UTF-8');
    $texto = str_replace(" De ", " de ", $texto);
    $texto = str_replace(" La ", " la ", $texto);
    $texto = str_replace(" Y ", " y ", $texto);
    $texto = str_replace(" Ii", " II", $texto);
    $texto = str_replace(" Iii", " III", $texto);
    return $texto;

}

function nombre_mes($mes) {
	
	switch ($mes) {

	case 1:
		$nombremes='ENERO';
		break;
		case 2:
		$nombremes='FEBRERO';
		break;
		case 3:
		$nombremes='MARZO';
		break;
		case 4:
		$nombremes='ABRIL';
		break;
		case 5:
		$nombremes='MAYO';
		break;
		case 6:
		$nombremes='JUNIO';
		break;
		case 7:
		$nombremes='JULIO';
		break;
		case 8:
		$nombremes='AGOSTO';
		break;
		case 9:
		$nombremes='SEPTIEMBRE';
		break;
		case 10:
		$nombremes='OCTUBRE';
		break;
		case 11:
		$nombremes='NOVIEMBRE';
		break;
		case 12:
		$nombremes='DICIEMBRE';
		break;
	}
	return $nombremes;
}