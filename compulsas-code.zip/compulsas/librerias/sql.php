<?php

require_once("../utilerias/connect.php");

if (!isset($_link)) {
    $_link = new mysqli($dbhost, $dbuser, $dbpass, $dbname);            
}

class sql {

    var $IdConexion = 0;
    var $errNo = 0;
    var $errMsg = "";
    var $errMsg2 = "";

    function runQuery($consulta, $regresarErrores = false) {
        // imprime_array($GLOBALS["link"]);
        global $_link;
        $this->IdConexion = mysqli_query($_link, $consulta);
        if (!$this->IdConexion) {
            $this->errMsg = "Error al ejecutar la consulta <i>$consulta</i>";
            $this->errNo = mysqli_errno($_link);
            $this->errMsg2 = mysqli_error($_link);

            if ($regresarErrores)
                return $this->errNo;
            else
                $this->error();

            exit();
            return 0;
        } else {
            return $this->IdConexion;
        }
    }

// runQuery

    function rows() {
        return mysqli_num_rows($this->IdConexion);
    }

// rows

    function data() {
        return mysqli_fetch_array($this->IdConexion);
    }

// array

    function error() {
        echo "<br><font face='verdana' size=2> &nbsp;&nbsp;&nbsp;&nbsp;";
        echo $this->errMsg . " <br><br>&nbsp;&nbsp;&nbsp;&nbsp;Favor de reportarlo con administrador del sistema</font><br><bR>";
        ?>
        <center>
            <br>
            <table border="1" width="500" id="table1" bordercolor="#FF9900"
                   style="border-collapse: collapse">
                <tr>
                    <td colspan="2" align="center" bgcolor="#FFCC66"><b> <font
                                face="Verdana" size="2">Detalles del Error</font></b></td>
                </tr>
                <tr>
                    <td width="72" align="center" bgcolor="#FFCC66"><font face="Verdana"
                                                                          size="2">C&oacute;digo</font></td>
                    <td width="412" align="center" bgcolor="#FFCC66"><font face="Verdana"
                                                                           size="2">Descripci&oacute;n</font></td>
                </tr>
                <tr>
                    <td width="72" align="center"><?echo $this->errNo;?></td>
                    <td width="412" align="center"><?echo $this->errMsg2;?></td>
                </tr>
            </table>
        </center>
        <br>
        <br>
        <?php

    }

// error

    function combo($query, $name, $value, $enable, $onchange, $iniselect, $clase, $multiples = array(), $idAlterno = "", $seleccion = "[ Seleccione ]") {
        $idAlterno = trim($idAlterno);

        if ($this->runQuery($query)) {
            $idx = (empty($idAlterno)) ? $name : $idAlterno;
            echo "<select name='$name' id ='$idx' $clase style='' $enable $onchange>";
            if ($this->rows() == 0)
                echo "<option value='0'>'No hay opciones !!'</option>";
            else {
                if ($iniselect == 1)
                    echo "<option value='0'>$seleccion</option>";
                while (list ( $id, $descrip ) = mysqli_fetch_row($this->IdConexion)) {
                    if ($enable == "multiple='multiple'") {
                        echo (in_array($id, $multiples)) ? "<option selected value='$id'>" . utf8_encode($descrip) . "</option>" : " <option value='$id'>$descrip</option>";
                    } else {
                        if ($id == $value)
                            echo "<option selected value='$id'>" . utf8_encode($descrip) . "</option>";
                        else
                            echo "<option value='$id'>" . utf8_encode($descrip) . "</option>";
                    }
                }
            } // end else
            echo "</select>";
        }
    }

// combo

    function combo2($query, $name, $value, $enable, $onchange, $iniselect, $clase, $multiples = array(), $idAlterno = "", $seleccion = "[ Seleccione ]") {
        $idAlterno = trim($idAlterno);

        if ($this->runQuery($query)) {
            $idx = (empty($idAlterno)) ? $name : $idAlterno;
            echo "<select name='$idx' id ='$idx' $clase style='' $enable $onchange>";
            if ($this->rows() == 0)
                echo "<option value='0'>'No hay opciones !!'</option>";
            else {
                if ($iniselect == 1)
                    echo "<option value='0'>$seleccion</option>";
                while (list ( $id, $descrip ) = mysqli_fetch_row($this->IdConexion)) {
                    if ($enable == "multiple='multiple'") {
                        echo (in_array($id, $multiples)) ? "<option selected value='$id'>" . utf8_encode($descrip) . "</option>" : " <option value='$id'>$descrip</option>";
                    } else {
                        if ($id == $value)
                            echo "<option selected value='$id'>" . utf8_encode($descrip) . "</option>";
                        else
                            echo "<option value='$id'>" . utf8_encode($descrip) . "</option>";
                    }
                }
            } // end else
            echo "</select>";
        }
    }

// combo        

    function table($query) {
        if ($this->runQuery($query)) {
            $columnas = mysqli_num_fields($this->IdConexion);
            echo "<center><table border='1' style='border-collapse: collapse' bordercolor='#000066'>";
            echo "<tR>
                <td bgcolor='#000066'><font face='verdana' size=1 color='#FFFFFF'>No</td>
                ";
            while ($nameField = mysqli_fetch_field($this->IdConexion)) {
                echo "<td bgcolor='#000066'><font face='verdana' size=1 color='#FFFFFF'>" . $nameField->name . "</td>";
            }
            echo "</tr>";
            $x = 1;
            for ($i = 0; $i < $this->rows(); $i ++) {
                echo "<tr>
                    	<td>$x</td>
                    ";
                $dump = $this->data();
                for ($j = 0; $j < $columnas; $j ++) {
                    echo "<td bgcolor='#FFFFFF'><font face='verdana' size=1 color='#000000'>" . utf8_encode($dump [$j]) . "</td>";
                }
                echo "</tr>";
                $x ++;
            }
            echo "</table></center><br>";
        }
    }

// table

    function datosEnArray($query, $campoIndexa = "", $nobr = false) {
        if ($this->runQuery($query)) {

            $arrayTemp = array();
            $fields = array();

            $columnas = mysqli_num_fields($this->IdConexion);
            while ($nameField = mysqli_fetch_field($this->IdConexion)) {
                $fields [] = $nameField->name;
            }

// 			imprime_array($fields);

            for ($i = 0; $i < $this->rows(); $i ++) {
                $arrayField = array();

                $datosTemp = $this->data();
                for ($j = 0; $j < count($fields); $j ++) {
                    if ($nobr) {
                        $arrayField [$fields [$j]] = utf8_encode($datosTemp [$fields [$j]]);
                    } else {
                        $arrayField [$fields [$j]] = utf8_encode(nl2br($datosTemp [$fields [$j]]));
                    }
                }
                if (empty($campoIndexa))
                    $arrayTemp [$i] = $arrayField;
                else
                    $arrayTemp [$datosTemp[$campoIndexa]] = $arrayField;
            }
            //imprime_array($arrayTemp);
            return $arrayTemp;
        }
    }

    function libera() {
        mysqli_free_result($this->IdConexion);
    }

    function filasAfectadas() {
        return mysqli_affected_rows($this->IdConexion);
    }

    function cierra() {
        global $_link;        
        mysqli_close($_link);
    }

// cierra
}
function insertaDatos($table, $tableValues, $returnLastId) {
	if (count ( $tableValues ) == 0) {
		echo "Error. tabla --> vacio. InsertaDatos";
		require ("abajo.php");
		exit ();
	}
	
	$camposTabla = obtieneCamposTabla ( $table );
	
	$sql = new sql ();
	
	// imprime_array($camposTabla);
	// exit;
	
	foreach ( $tableValues as $id => $valor ) {
		if (! in_array ( $id, $camposTabla ))
			continue;
		
		$fields .= "$id,";
		$values .= "'$valor',";
	}
	
	$fields = rtrim ( $fields, " , " );
	$values = rtrim ( $values, " , " );
	
	// echo "insert into $table($fields) values($values)";
	// exit();
	
	$consulta = $sql->runQuery ( "insert into $table($fields) values($values)" );
	if (! $consulta) {
		return false;
	}
	if ($returnLastId) {
		$sql->runQuery ( "select LAST_INSERT_ID() as last" );
		$data = $sql->data ();
		return $data ["last"];
	} else
		return TRUE;
}
function insertaDatosDirecto($table, $tableValues, $returnLastId) {
	if (count ( $tableValues ) == 0) {
		echo "Error. tabla --> vacio. InsertaDatos";
		require ("abajo.php");
		exit ();
	}
	
	$sql = new sql ();
	
	foreach ( $tableValues as $id => $valor ) {
		$fields .= "$id,";
                if ($valor === 'NULL') {
                    $values .= "NULL,";
                } else {
                    $values .= "'$valor',";
                }
	}
	
	$fields = rtrim ( $fields, " , " );
	$values = rtrim ( $values, " , " );
	
	// echo "insert into $table($fields) values($values)";
	// exit();
	
	$sql->runQuery ( "insert into $table($fields) values($values)" );
	
	if ($returnLastId) {
		$sql->runQuery ( "select LAST_INSERT_ID() as last" );
		$data = $sql->data ();
		return $data ["last"];
	} else
		return TRUE;
}
// class