<?php
function barrafiltros($formulario, $id_reporte = 0) {
    global $lm;

	$id_pagina = 0;
    $search_box = "";
    $query_string = "";
    $where_filtros = " ";
    $custom_sql_grid = false;
    $custom_order = "";
	$codigojs="";
    $combos="";
	$cant_letras_formulario=strlen($formulario);
    $parametro = array();
      $autofiltro = array('Search_Box' => $search_box, 'Query_String' => $query_string, 'Sql_Param' => $parametro, "Filtro" => $where_filtros, 'JS'=>$codigojs, 'Combos'=>$combos,'id_pagina'=>$id_pagina);
    $busca_id = "select * from pagina where left(pagina.pagina,$cant_letras_formulario)='$formulario'";
    $rs_id = $lm->query($busca_id);
    if ($rs_id) {

            $id_pagina = $rs_id[0]['id_pagina'];

    }

	    if ($_SESSION['SesGrupo'] == 1) {
        $lm->puede_agregar = true;
        $lm->puede_borrar = true;
        $lm->puede_editar = true;
        $lm->puede_exportar = true;
	} else {
    //***** PERMISOS EN AUTOMATICO***
    if ($id_reporte > 0) {
            $accesoreporte = permisos_reporte($id_reporte);
            if (substr($_SESSION['SesPermisosReporte'], 0, 1) != 1) $lm->puede_agregar = false;
            if (substr($_SESSION['SesPermisosReporte'], 1, 1) != 1) $lm->puede_editar = false;
            if (substr($_SESSION['SesPermisosReporte'], 2, 1) != 1) $lm->puede_borrar = false;
            if (substr($_SESSION['SesPermisosReporte'], 6, 1) != 1) $lm->puede_exportar = false;
        } 
	if($id_pagina > 0) {
            $accesopage = permisos($id_pagina);
            if ($accesopage == false) {
                fnMsgErrorAcceso();
                exit();
            }
            if (substr($_SESSION['SesPermisos'], 0, 1) != 1) $lm->puede_agregar = false;
            if (substr($_SESSION['SesPermisos'], 1, 1) != 1) $lm->puede_editar = false;
            if (substr($_SESSION['SesPermisos'], 2, 1) != 1) $lm->puede_borrar = false;
            if (substr($_SESSION['SesPermisos'], 6, 1) != 1) $lm->puede_exportar = false;
        }
			// copiamos los mismos permisos para la BD Obras
	}
    
    //***FIN DE PERMISOS ***********
    $condicion = " ";

	$linea=array(4,7,10);
    $lm->grid_show_search_box = false;
    if ($id_reporte > 0) $condicion = " and id_reporte=$id_reporte ";
    elseif ($id_pagina > 0) $condicion = " and id_pagina=$id_pagina ";
    $busca_filtro = "select * from filtros where 1 $condicion order by  filtros.orden_filtro";
    // echo $busca_id, '|',$id_pagina,'|',$busca_filtro;
    $rs_filtro = $lm->query($busca_filtro);
	//echo count($rs_filtro);
    if (count($rs_filtro) != NULL) {
		
        $lm->grid_show_search_box = true;
        $codigo_filtros = "";
        $i = 1; //indice
        $new_search_ = array();
        $input = "";
        foreach ($rs_filtro as $fila) {
            $encabezado = $fila['placeholder'];
        }
        $input.= "";
		
        foreach ($rs_filtro as $fila) {
			if(in_array($i,$linea)) $salto_linea=" <br>"; else $salto_linea="";
            $new_search_[$i] = $lm->clean_out(@$_REQUEST["new_search_" . $i]);
            $type = $fila['type'];
            if ($fila['size'] == NULL) $size=15; else $size = $fila['size'];
            $name = $fila['name'];
			$placeholder = $fila['placeholder'];

            if ($type = $fila['type'] == 'select') {
				$query=$fila['combo_query'];


				
				   $input.= "<div class='position-relative form-group'><label for='new_search_$i' class='mr-sm-2'>$placeholder</label><select onchange='myFunction2()' value='$new_search_[$i]' id='new_search_$i' name='new_search_$i'  class='form-control'> " .
				llenarcombo($query, $fila['campo_id_combo'],'c2',$placeholder) . "  </select></div> \n";
           
				$combos.=$query. "| ";
                if(strlen($new_search_[$i])>0)
                    $codigojs.= "document.getElementById('new_search_$i').value = '$new_search_[$i]';\n";
                 else  
                      $codigojs.= "document.getElementById('new_search_$i').value = '';\n";
            }
            else $input.= "	<div class='mb-2 mr-sm-2 mb-sm-0 position-relative form-group'><label for='new_search_$i' class='mr-sm-2'>$placeholder</label><input name='new_search_$i' id='new_search_$i' placeholder='$placeholder' type='$type' size=$size class='form-control'></div>
			 \n";
			     if(strlen($new_search_[$i])>0)
                    $codigojs.= "document.getElementById('new_search_$i').value = '$new_search_[$i]';\n";
                 else  
                      $codigojs.= "document.getElementById('new_search_$i').value = '';\n";			 
            $i = $i + 1;	 


        }
			//	<input type='$type' name='new_search_$i' value='$new_search_[$i]' size=$size class='lm_search_input'  placeholder='$placeholder' > $salto_linea;

			$reset=basename($_SERVER['PHP_SELF']);
            $search_box = " 
			<form class='form-inline'>
			$input 
			<a href='$reset' class='btn btn-warning' title='Clear Search'>Limpiar Filtro</a>
			<input type='submit' id='botonfiltro' name='botonfiltro' value='Buscar' class='btn btn-info'>
			<input type='hidden' name='action' value='search'>

			</form>";		
        $x = 1;
        foreach ($rs_filtro as $fila) {
            $nombre_campo = $fila['name'];
            $dato_busca = trim(@$_REQUEST["new_search_" . $x]);
            $parametro[":new_search_$x"] = trim(@$_REQUEST["new_search_" . $x]);
            if ($x == 1) $query_string.= "new_search_$x";
            else $query_string.= ",new_search_$x";
            if ($fila['type'] == 'number' and $dato_busca != NULL) $where_filtros.= " and coalesce($nombre_campo, 1) = $dato_busca ";
            else {
                if ($fila['type'] == 'text') $where_filtros.= " and coalesce($nombre_campo, '')   like '%$dato_busca%'";
                if ($fila['type'] == 'select' and $dato_busca != NULL) $where_filtros.= " and coalesce($nombre_campo, '')   = '$dato_busca'";
            }
            $x = $x + 1;
        }
    }
    //*** FIN DE FILTROS DESDE TABLA
    $lm->grid_search_box = $search_box;
    $lm->query_string_list = $query_string;
    $lm->grid_sql_param = $parametro;
    // add variable names to querystring so search is perserved when paging, sorting, and editing
    $autofiltro = array('Search_Box' => $search_box, 'Query_String' => $query_string, 'Sql_Param' => $parametro, "Filtro" => $where_filtros, 'JS'=>$codigojs, 'Combos'=>$combos,'id_pagina'=>$id_pagina);
    //**** APLICACION DE CODIGO EXTRA PARA GRID O FORMULARIO
    $condicion_codigo = " ";
    if ($id_reporte > 0) $condicion_codigo = " and id_reporte=$id_reporte ";
    elseif ($id_pagina > 0) $condicion_codigo = " and id_pagina=$id_pagina ";
    $busca_codigo = "select * from extracode where 1 $condicion_codigo ";
    $rs_code = $lm->query($busca_codigo);
    if ($rs_code) {
        foreach ($rs_code as $fila_extra) {
            $extra = $fila_extra['metodo'];
            $campo = $fila_extra['campo'];
            $parametro = $fila_extra['parametro'];
            $salida = $fila_extra['tiposalida'];
            switch ($extra) {
                case "form_input_control":
                    $lm->form_input_control[$campo] = "--$salida";
                break;
                case "form_input_control--select":
                    $lm->form_input_control[$campo] = "$parametro; --select";
                break;
                case "rename":
                    $lm->rename[$campo] = "$parametro";
                break;
                case "form_sql":
                    $lm->form_sql = $parametro;
                break;
                case "table":
                    $lm->table = '$parametro';
                break;                
                case "identity_name":
                    $lm->identity_name = $campo;
                break;                
                case "grid_sql":
                    //aplicaremos el query al final
                    $custom_sql_grid = true;
                    $custom_query = $parametro;
                break;
                case "upload_path":
                    $lm->upload_path = "$parametro";
                break;
                case "form_text_input_size":
                    $lm->form_text_input_size = $parametro;
                break;
                case "grid_input_control":
                    $lm->grid_input_control[$campo] = "--$salida";
                break;
                case "grid_multi_delete":
                    $lm->grid_multi_delete = $parametro;
                break;
                case "grid_limit":
                    $lm->grid_limit = $parametro;
                break;
                case "grid_output_control":
                    $lm->grid_output_control[$campo] = "--$salida";
                break;
                case "form_default_value":
                    $lm->form_default_value = "$parametro";
                break;
                case "grid_default_order_by":
                    $custom_order = $parametro;
                break;
                case "grid_area_cols_size":
                    $lm->grid_area_cols_size = $parametro;
                break;
                case "grid_area_rows_size":
                    $lm->grid_area_rows_size = $parametro;
                break;
                case "return_to_edit_after_insert":
                    $lm->return_to_edit_after_insert = $parametro;
                break;
                case "return_to_edit_after_update":
                    $lm->return_to_edit_after_update = $parametro;
                break;
                case "grid_repeat_header_at":
                    $lm->grid_repeat_header_at = $parametro;
                break;
                case "grid_text_input_size":
                    $lm->grid_text_input_size = $parametro;
                break;
                case "grid_number_input_size":
                    $lm->grid_number_input_size = $parametro;
                break;
            }
        }
    }
    if ($custom_sql_grid == true) {
        if ($custom_order <> "") $order_by = " order by " . $custom_order;
        else $order_by = "";
        $lm->grid_sql = $custom_query . " where 1 " . $where_filtros . $order_by;
    }
    return $autofiltro;
}
//****
function llenarcombo($query = "", $valor = 0, $descrip = "c2",$placeholder) {
    global $dbh;
  //  $combo = "<option value=''>$placeholder</option>";
    //$combo="";
    $combo="<option value=''>$placeholder...</option>";
    foreach ($dbh->query($query) as $row) {
        $combo.= "<option value=" . $row[$valor] . ">" . $row[$descrip] . "</option>";
    }
    return $combo;
}
function permisos($id_pagina) {
    global $lm;
    $Sql = "SELECT
  if(perfil.nuevo=1,1,0) as nuevo,
  if(perfil.modificar=1,1,0) as modificar,
  if(perfil.eliminar=1,1,0) as eliminar,
  if(perfil.vista=1,1,0) as vista,
  if(perfil.buscar=1,1,0) as buscar,
  if(perfil.html=1,1,0) as html,
  if(perfil.excel=1,1,0) as excel
FROM
  pagina
  INNER JOIN perfil ON pagina.id_pagina = perfil.id_pagina
where perfil.id_usuario =" . $_SESSION['SesIdUsuario'] . " AND  pagina.id_pagina = $id_pagina";
    $query = $lm->query($Sql);
    if (count($query) > 0) {
        $_SESSION['SesPermisos'] = $query[0]['nuevo'] . $query[0]['modificar'] . $query[0]['eliminar'] . $query[0]['vista'] . $query[0]['buscar'] . $query[0]['html'] . $query[0]['excel'];
        return true;		
	}
else {
	
    $Sql = "SELECT
  if(perfil.nuevo=1,1,0) as nuevo,
  if(perfil.modificar=1,1,0) as modificar,
  if(perfil.eliminar=1,1,0) as eliminar,
  if(perfil.vista=1,1,0) as vista,
  if(perfil.buscar=1,1,0) as buscar,
  if(perfil.html=1,1,0) as html,
  if(perfil.excel=1,1,0) as excel
FROM
  pagina
  INNER JOIN perfil ON pagina.id_pagina = perfil.id_pagina
where perfil.id_mnu =" . $_SESSION['SesMnu'] . " AND  pagina.id_pagina = $id_pagina";
    $query = $lm->query($Sql);
    if (count($query) > 0) {
        $_SESSION['SesPermisos'] = $query[0]['nuevo'] . $query[0]['modificar'] . $query[0]['eliminar'] . $query[0]['vista'] . $query[0]['buscar'] . $query[0]['html'] . $query[0]['excel'];
        return true;
    }
}	
	}
function permisos_reporte($id_reporte) {
    global $lm;
    $menu = $_SESSION['SesMnu'];
	$usuario= $_SESSION['SesIdUsuario'];
    $Sql = "Select
  if(perfil_query.nuevo=1,1,0) as nuevo,
  if(perfil_query.modificar=1,1,0) as modificar,
  if(perfil_query.eliminar=1,1,0) as eliminar,
  if(perfil_query.vista=1,1,0) as vista,
  if(perfil_query.buscar=1,1,0) as buscar,
  if(perfil_query.html=1,1,0) as html,
  if(perfil_query.excel=1,1,0) as excel
From
    perfil_query  Join
    reporte On reporte.id_reporte = perfil_query.id_reporte
    where perfil_query.id_reporte=$id_reporte and perfil_query.id_mnu=$menu or perfil_query.id_usuario=$usuario";
    $query = $lm->query($Sql);
	$_SESSION['xx']=$Sql;
    if (count($query) > 0) {
        $_SESSION['SesPermisosReporte'] = $query[0]['nuevo'] . $query[0]['modificar'] . $query[0]['eliminar'] . $query[0]['vista'] . $query[0]['buscar'] . $query[0]['html'] . $query[0]['excel'];
        return true;
    }
}
function fnMsgErrorAcceso() { ?>
<img  src="assets/images/forbidden.png"/>
<h2>Acceso denegado!</h2>

<?php
}


?>
