<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
<body>
                                <h4>Grupo de usuarios</h4>
<?php
try {
	$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
}
catch(PDOException $e) {
	die('pdo connection error: ' . $e->getMessage());
}

// create LM object, pass in PDO connection
$lm = new lazy_mofo($dbh); 


// table name for updates, inserts and deletes
$lm->table = 'grupo';



 $lm->return_to_edit_after_insert = false;
 $lm->return_to_edit_after_update = false;
// identity / primary key for table
$lm->identity_name = 'id_grupo';


// optional, make friendly names for fields
	if ($_SESSION['SesGrupo']==1) {
		$lm->puede_agregar=true;
		$lm->puede_borrar=true;
		$lm->puede_editar=true;
		$lm->puede_exportar=true;
	} else {
			if(substr($_SESSION['SesPermisos'],0,1)!="S") $lm->puede_agregar=false;
		if(substr($_SESSION['SesPermisos'],1,1)!="S") $lm->puede_editar=false;		
		if(substr($_SESSION['SesPermisos'],2,1)!="S") $lm->puede_borrar=false;
		if(substr($_SESSION['SesPermisos'],6,1)!="S") $lm->puede_exportar=false;
		
	}
//$lm->rename['nombres'] = 'Nombres';
//$lm->rename['fechanacimiento'] = 'Fecha';


// optional, define input controls on the form
//$lm->form_input_control['is_active'] = "select 1, 'Yes' union select 0, 'No' union select 2, 'Maybe'; --radio";
//$lm->form_input_control['fechanacimiento'] = ' --date';
//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';


$lm->date_out = 'd/m/Y';
// optional, define editable input controls on the grid

//$lm->grid_input_control['fechanacimiento'] = '--date';
//$lm->grid_input_control['nombres'] = '--readonly';


// optional, define output control on the grid 
//$lm->grid_output_control['contact_email'] = '--email'; // make email clickable
//$lm->grid_output_control['photo'] = '--image'; // image clickable  


// new in version >= 2015-02-27 all searches have to be done manually

//$lm->grid_show_search_box = true;


// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
$lm->grid_sql = "SELECT
grupo.id_grupo as ID,
  grupo.nombre_grupo,
  grupo.id_grupo
FROM
  grupo";

$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';

		$lm->form_sql = "SELECT
		
  grupo.nombre_grupo,
  grupo.id_grupo
FROM
  grupo  where id_grupo = :id_grupo ";

// optional, define what is displayed on edit form. identity id must be passed in also.  
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 

// use the lm controller
$lm->run();

?>



</body>
</html>
