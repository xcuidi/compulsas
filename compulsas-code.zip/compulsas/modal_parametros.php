<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
<body>
<?php 
	try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		
		$lm->primary_form=false; // Indicamos que no es un formulario principal
		
		// create LM object, pass in PDO connection
	//	$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'extracode';
		

		// identity / primary key for table
		$lm->identity_name = 'id';
				$lm->puede_exportar=true;
				$lm->puede_editar=true;
				$lm->puede_borrar=true;
				$lm->puede_agregar=true;
				
		$lm->date_out = 'Y-m-d';  //Para editar se requieren el "guion medio"	
	$lm->date_in = 'Y-m-d';	
		$lm->form_input_control['metodo'] = "Select
    catalogo.valor as c1,
    catalogo.valor,
    catalogo.tipo
From
    catalogo
Where
    catalogo.tipo = 'EXTRACODE'
Order By
    catalogo.valor; --select";			
		// optional, define editable input controls on the grid
		
	//	$lm->grid_show_search_box = true;
		$lm->form_default_value['id_reporte']=$_SESSION['Tempo_Reporte'];	
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		

		$lm->grid_sql = "Select
    extracode.id_reporte,
    extracode.metodo,
    extracode.campo,
    extracode.parametro,
    extracode.tiposalida,
    extracode.id
From
    extracode where extracode.id_reporte=".$_SESSION['Tempo_Reporte']."
  order by extracode.id_reporte, extracode.campo, extracode.parametro";

	//	echo $lm->grid_sql;
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
		// optional, define what is displayed on edit form. identity id must be passed in also.  

		// use the lm controller
		$lm->run();
?>


<a href="https://rawgit.com/lazymofo/datagrid/master/index.html#native_input_controls" target="_blank" > Documentacion de Lazy Mofo</a>




</body>
</html>
