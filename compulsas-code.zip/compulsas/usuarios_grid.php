<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
<div class="card-header">
                <h5 class="card-title">USUARIOS DEL SISTEMA</h5>
</div>
	<?php


		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
		//$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'usuario';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_usuario';

    //***************************** CODIGO DE AUTOFILTROS **********************************	/
		$formulario = basename($_SERVER['PHP_SELF']);
		include("codigo_filtros.php");	
		$Where_filtros=barrafiltros($formulario,0);	
		$condicion=$Where_filtros['Filtro'];
		$JavaScript= $Where_filtros['JS'];
		
			//REGRESA ARREGLO CON 2 VARIABLES: Search_Box Y Filtro

//***************************** *******************************************************	/	
$filtro_admin=" and id_tipo_usuario >1";
if ($_SESSION['SesGrupo']==1) $filtro_admin="";

$query_usuarios="Select
    mnu.nombre As Menu,
    usuario.nombre,
    usuario.usuario,
    usuario.correo,
    usuario.usuario_activo,
    usuario.id_usuario
From
    usuario left Join
    tipo_usuario On tipo_usuario.id_tipo_usuario = usuario.id_tipo_usuario Inner Join
    mnu On mnu.id_mnu = tipo_usuario.id_mnu
where 1 $condicion $filtro_admin";
    

$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=15;
		
		// optional, make friendly names for fields
		
		$lm->rename['usuario_activo'] = 'Activo';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		
		
		// optional, define input controls on the form
		//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';
// optional, define editable input controls on the grid
		//$lm->form_input_control['is_active'] = "select 1, 'Yes' union select 0, 'No' union select 2, 'Maybe'; --radio";
		$lm->form_input_control['usuario_activo'] = '--checkbox';
		$lm->form_input_control['usuario_especial'] = '--checkbox';
		$lm->form_input_control['mail_aviso_seguim'] = '--checkbox';
		$lm->form_input_control['redes_sociales'] = '--checkbox';
		$lm->form_input_control['foto'] = '--image';
		$lm->grid_input_control['usuario_activo'] = '--checkbox';
		$lm->grid_input_control['redes_sociales'] = '--checkbox';
		$lm->form_input_control['enlace_oficialia'] = '--checkbox';
		$lm->grid_output_control['foto'] = '--image';         // make image clickable  
		$lm->upload_path="profilepic";	

		$lm->on_insert_validate['id_tipo_usuario'] = array('/.+/', 'Falta tipo de usuario', 'Requerido'); 
	//	$lm->on_insert_validate['id_mnu'] = array('/.+/', 'Falta tipo de usuario', 'Requerido'); 
		
		$lm->form_input_control['id_estructura'] = "SELECT
  estructura.id_estructura,
  estructura.nombre_puesto

FROM
  estructura; --select";

  		$lm->form_input_control['id_mnu'] = "Select
    mnu.id_mnu,
    mnu.nombre
From
    mnu
Order By
    mnu.nombre; --select";
	
		$lm->form_input_control['id_tipo_usuario'] = "SELECT
  tipo_usuario.id_tipo_usuario,
  tipo_usuario.descrip
FROM
  tipo_usuario where 1 $filtro_admin; --select";


			
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  

		
		$lm->grid_sql = $query_usuarios;
	
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	
		// use the lm controller
		$lm->run();
//}
	
								
	
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama�o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.


global $lm;
$editable=false;

	$parametro=$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
?>
	
	<div class="md-card-content">
		<div class="uk-grid" data-uk-grid-margin="">	
			<div class="uk-width-medium-1-3 uk-row-first">
							<h3 class="heading_a">Datos de Acceso</h3>

								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Nombre completo</label>
										<?php imprimir($recordset["nombre"],30);	?>
									</div>
									
								</div>	
						
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Nombre de Usuario</label>
										<?php imprimir($recordset["usuario"],30);?>
									</div>
									
								</div>	
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Clave</label>
										<?php imprimir($recordset["clave"],30);?>
									</div>
									
								</div>		
							

			</div>
		<div class="uk-width-medium-1-3">
						<h3 class="heading_a">Datos de Contacto</h3>

                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Calle y número</label>
									<?php imprimir($recordset["calle"],30);	?>
								</div>
                                
                            </div>	
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Colonia</label>
									<?php imprimir($recordset["colonia"],30);	?>
								</div>
                                
                            </div>								
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Municipio</label>
									<?php imprimir($recordset["municipio"],30);	?>
								</div>
                                
                            </div>							
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>CP</label>
									<?php imprimir($recordset["cp"],30);?>
								</div>
                                
                            </div>	
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Telefono 1</label>
									<?php imprimir($recordset["telefono1"],30);?>
								</div>
                                
                            </div>
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Telefono 2</label>
									<?php imprimir($recordset["telefono2"],30);?>
								</div>
                                
                            </div>
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Correo Electronico</label>
									<?php imprimir($recordset["correo"],30);?>
								</div>
                                
                            </div>								

		</div>

		<div class="uk-width-medium-1-3">
						<h3 class="heading_a">Tipo de Usuario</h3>

                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Tipo de Usuario</label>
									<?php imprimir($recordset["id_tipo_usuario"],30);	?>
								</div>
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Zona</label>
										<?php imprimir($recordset["id_zona"],30);	?>
									</div>
									
								</div>								
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Seccion</label>
										<?php imprimir($recordset["seccion"],30);	?>
									</div>
									
								</div>	                                
                            </div>
                            <div class="uk-form-row">
                                <div class="md-input">
									<label>Usuario activo</label>
									<?php imprimir($recordset["usuario_activo"],30);	?>
								</div>
                                
                            </div>							

							

		</div>		
	</div>
</div>
 <?php
} // fin plantilla

?>
<script>
	function myFunction2() {
	document.getElementById("botonfiltro").click()
	}
</script>


<script>
<?php echo $JavaScript; ?>
</script>

</body>
</html>