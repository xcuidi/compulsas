<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

<body>
<?php   

 $nombre_entidad = key_exists('entidad', $_GET) ? $_GET['entidad'] : 0; 
 echo $nombre_entidad;
 $entidad = str_replace('*',' ',$nombre_entidad);
 
 $id_ur = key_exists('id_ur', $_GET) ? $_GET['id_ur'] : 0; 
 

	
?>
	<br>
<form method="post" action="<?=$_SERVER['PHP_SELF']?>" id="frmDatos" class="bordered">
<table width="100%" border="0" cellspacing="3">
  <tr>
    <th scope="row"> <?php  ?></th>
    <td width="11%" scope="row"><a class='btn btn-warning' href="identifica_ur_bloque.php" title="Otros reportes"><strong>Regresar</strong></a></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="3" class="datacell">
  <tr>
    <td scope="row"><?php ?></td>
    </tr>
</table>
</form>
<?php 
 
												
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		$lm = new lazy_mofo($dbh); 
		
	$sql_identifica="update tabla_siox set id_ur=$id_ur where razon_social='$entidad'";
	echo $sql_identifica;
	$lm->query($sql_identifica);
	


?>							
								

</body>
</html>

