<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

                  
                                <h4>Menus desplegables</h4>
	<?php
 
		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
	//	$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'mnu_detp';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_mnu_detp';
	$lm->timezone='Mexico/General';
$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=15;
		
		// optional, make friendly names for fields
		
	//	$lm->rename['usuario_activo'] = 'Activo';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		
		$lm->form_input_control['id_mnu'] = "SELECT
  mnu.id_mnu as c1,
  concat(id_mnu, ' | ', mnu.nombre) as c2
FROM
  mnu; --select";
		
		$lm->grid_input_control['activo'] = "--checkbox";
		
	
		
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid
		
	// define our own search form with two inputs instead of the default one
////BUSQUEDAS
	$lm->grid_show_search_box = true;

$new_search_1 = $lm->clean_out(@$_REQUEST['new_search_1']);
$new_search_2 = $lm->clean_out(@$_REQUEST['new_search_2']);


function llenarcombo($query="",$valor=0,$descrip="") {
	global $dbh;
	$combo="<option value=''>Buscar..</option>";
	 foreach($dbh->query($query) as $row) {
 		// $combo.= '<option value="'.$row['id_diocesis'].'">'.$row['diocesis'].'<option/>';
		//$combo.= '<option value="'.$row['$valor'].'">'.$row['$descrip'].'<option/>';
		$combo.= "<option value=".$row[$valor].">".$row[$descrip]."</option>";
		
  		}

		return $combo;
}

// define our own search form with two inputs instead of the default one
////	<input type='text' name='new_search_1' value='$new_search_1' size='20' class='lm_search_input' placeholder='Diocesis'>
$lm->grid_search_box = "

<form class='lm_search_box'>

 <select name='new_search_1' value=$new_search_1 class='lm_search_input' placeholder='Selecciones Menu'>	> "
 .llenarcombo("SELECT   mnu.id_mnu,   mnu.nombre FROM   mnu","id_mnu","nombre")."
  </select>
  	<input type='text' name='new_search_2' value='$new_search_2' size='20' class='lm_search_input' placeholder='Menu desplegable '>

	<input type='submit' value='Buscar' class='lm_button'>
	<input type='hidden' name='action' value='Buscar'>
</form>
"; 
// echo $lm->grid_search_box;
$lm->query_string_list = "new_search_1,new_search_2"; // add variable names to querystring so search is perserved when paging, sorting, and editing
// set name parameters

if (@$_REQUEST['new_search_1'] > 0) {// obligamos a que la busqueda solo sea numerica

	$lm->grid_sql_param[':new_search_2'] = "DATO NUMERICO"; 
	} else {
$lm->grid_sql_param[':new_search_1'] =  '%' . @$_REQUEST['new_search_1'] . '%';
$lm->grid_sql_param[':new_search_2'] = '%' . @$_REQUEST['new_search_2'] . '%';

}
$lm->grid_sql_param[':new_search_1'] =    @$_REQUEST['new_search_1'] ;	
//$lm->grid_sql_param[':new_search_5'] =    @$_REQUEST['new_search_5'] ;
// set name parameters
		
$query_menup="SELECT
  concat(mnu.id_mnu, ' | ', mnu.nombre) AS `Menu Usuario`,
  concat(mnu_detp.id_mnu_detp,' | ',mnu_detp.etiqueta) AS `Menu Padre`,
   mnu_detp.icono,
  mnu_detp.orden_menu AS orden,
  mnu_detp.activo,
  mnu_detp.id_mnu_detp
FROM
  mnu
  INNER JOIN mnu_detp ON mnu_detp.id_mnu = mnu.id_mnu
  where
  mnu.id_mnu = :new_search_1  or 
  coalesce(mnu_detp.etiqueta, '') like :new_search_2
   order by mnu.id_mnu, mnu_detp.orden_menu";		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		
		
		$lm->grid_sql = $query_menup;
	//	echo "R: ",$_SESSION['Where_Region']," D: ",$_SESSION['Where_Diocesis']," S: ", $_SESSION['Where_Sector'], " ROL: ", $_SESSION['Where_Rol'], " N: ",$_SESSION['Where_Nivel'],"<br>";
	
//		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
		$lm->form_sql = "SELECT
  mnu_detp.etiqueta,
  mnu_detp.orden_menu,
  mnu_detp.id_mnu_detp,
  mnu_detp.icono,
  mnu_detp.activo,
  mnu_detp.id_mnu
FROM
  mnu_detp
WHERE
  mnu_detp.id_mnu_detp = :id_mnu_detp";
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	//	$lm->form_default_value['condicion']=array(' where 1' );
		
//			echo $lm->grid_sql;
		// use the lm controller
		$lm->run();
//}
	
								
	
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama�o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
?>
<table class='table table-hover table-striped table-bordered'>
  <tr>
    <th colspan="2"><?php imprimir($recordset["lm_accion"],60);
			?></th>
  </tr>
  <tr>
    <td>Menu General </td>
    <td><?php imprimir($recordset["id_mnu"],20);
			?></td>
  </tr>
  <tr>
    <td width="166">Nombre del Menú </td>
    <td width="398"><?php imprimir($recordset["etiqueta"],20);
			?></td>
  </tr>
  <tr>
    <td>Orden</td>
    <td><?php imprimir($recordset["orden_menu"],80);
			?></td>
  </tr>
  <tr>
    <td>icono</td>
    <td><?php imprimir($recordset["icono"],80);
			?></td>
  </tr>
  <tr>
    <td>Iconos</td>
    <td><a href="https://www.bootstrapicons.com/index.htm?iconset=fontawesome&version=4.0.3" target="_blank"> https://www.bootstrapicons.com/index.htm?iconset=fontawesome&version=4.0.3</a></td>
  </tr>
</table>
 <?php
} // fin plantilla
?>


	
</body>
</html>