<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

<body>
                                <h4>Opciones de Menus desplegables</h4>
	<?php
 
		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
	//$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'mnu_deth';
		
		$lm->primary_form=false; // Indicamos que no es un formulario principal
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_mnu_deth';
				$lm->puede_exportar=false;
	
		$lm->puede_agregar=true;
		$lm->puede_borrar=true;
		$lm->puede_editar=true;
		$lm->puede_exportar=true;
$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=15;
		
		// optional, make friendly names for fields
		
	//	$lm->rename['usuario_activo'] = 'Activo';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		
		$lm->form_input_control['id_mnu_detp'] = "SELECT
  mnu_detp.id_mnu_detp,
  
  Concat(mnu.nombre,' > ',mnu_detp.id_mnu_detp, ' - ', mnu_detp.etiqueta) AS c2
FROM
  mnu_detp
  INNER JOIN mnu ON mnu.id_mnu = mnu_detp.id_mnu
ORDER BY
  mnu.id_mnu, mnu_detp.orden_menu, mnu_detp.etiqueta; --select";
	
$lm->grid_input_control['activo'] = "--checkbox";
	

	$lm->form_input_control['id_pagina'] = "SELECT
  pagina.id_pagina,
  Concat(pagina.nombre, ' | ', pagina.pagina) AS c2
FROM
  pagina order by pagina.nombre; --select";
		
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid
$id_mnu_detp=$_SESSION['TEMPO_MENUP'];
$query_menup="SELECT
    Concat(pagina.nombre, ' | ', pagina.pagina) AS Opcion,
   mnu_deth.orden_opcion,
   mnu_deth.activo,
  mnu_deth.id_mnu_deth
FROM
  mnu
  INNER JOIN mnu_detp ON mnu_detp.id_mnu = mnu.id_mnu
  INNER JOIN mnu_deth ON mnu_deth.id_mnu_detp = mnu_detp.id_mnu_detp
  LEFT JOIN pagina ON pagina.id_pagina = mnu_deth.id_pagina 
  where
  mnu_deth.id_mnu_detp=$id_mnu_detp
  
  order by mnu.id_mnu, mnu_detp.orden_menu, mnu_deth.orden_opcion";
		
		
		$lm->grid_sql = $query_menup;
	//	echo "R: ",$_SESSION['Where_Region']," D: ",$_SESSION['Where_Diocesis']," S: ", $_SESSION['Where_Sector'], " ROL: ", $_SESSION['Where_Rol'], " N: ",$_SESSION['Where_Nivel'],"<br>";
	//	echo $lm->grid_sql;
		
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
		$lm->form_sql = "SELECT
  mnu_deth.id_mnu_detp,
  mnu_deth.id_pagina,
  mnu_deth.orden_opcion,
  mnu_deth.activo,
  mnu_deth.id_mnu_deth
FROM
  mnu_deth
WHERE
  mnu_deth.id_mnu_deth = :id_mnu_deth";
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
		$lm->form_default_value['id_mnu_detp']=$_SESSION['TEMPO_MENUP'];
		
		
		// use the lm controller
		$lm->run();
//}
	
								
	
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama�o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
?>
<table  cellspacing="3" data-table='responsive' align="center">
  <tr>
    <th colspan="2"><?php imprimir($recordset["lm_accion"],60);
			?></th>
  </tr>
  <tr>
    <td>Menu Padre </td>
    <td><?php imprimir($recordset["id_mnu_detp"],20);
			?></td>
  </tr>
  <tr>
    <td width="166">Opción</td>
    <td width="398"><?php imprimir($recordset["id_pagina"],20);
			?></td>
  </tr>
  <tr>
    <td>Orden</td>
    <td><?php imprimir($recordset["orden_opcion"],80);
			?></td>
  </tr>
  <tr>
    <td>Activo</td>
    <td><?php imprimir($recordset["activo"],80);
			?></td>
  </tr>
</table>
 <?php
} // fin plantilla 
?>

 

</body>
</html>

