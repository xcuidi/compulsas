<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

    <body>
<div class="md-top-bar">
                <h5 class="card-title">Clientes de Inmobiliaria</h5>
</div>
	
     

									
									<?php 
									

                               

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		$lm = new lazy_mofo($dbh); 
		
		
		// table name for updates, inserts and deletes
		$lm->table = "cliente";
		
		 $lm->return_to_edit_after_insert = false;
	 $lm->return_to_edit_after_update = false;
		// identity / primary key for table
		$lm->identity_name = "id_cliente";

		
//***************************** CODIGO DE AUTOFILTROS **********************************	/
		$formulario = basename($_SERVER['PHP_SELF']);
		include("codigo_filtros.php");	
		$Where_filtros=barrafiltros($formulario,0);	
		$condicion=$Where_filtros['Filtro'];
		$JavaScript= $Where_filtros['JS'];
			//REGRESA ARREGLO CON 2 VARIABLES: Search_Box Y Filtro
//***************************** *******************************************************	/			
		
//OBTENEMOS UN NUEVO IDENTIFICADOR
$rs_ultimo=$lm->query("select max(id_cliente) as ultimo from cliente");
$nuevo=$rs_ultimo[0]['ultimo']+1;
$nuevo=str_pad($nuevo, 3, "0", STR_PAD_LEFT);
$lm->form_default_value['num_cliente']=date('Y')."/".$nuevo;
$lm->form_default_value['sexo']="M";
//*******FIN NUEVO */

$lm->form_custom_template = true; // SE ESPECIFICA QUE HAY UNA PLANTILLA
	
		$lm->date_out = 'd/m/Y';
			$lm->datetime_out = 'd/m/Y h:i A';  
		// optional, define editable input controls on the grid
		
			
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		$lm->grid_sql = "Select
	cliente.num_cliente,
    concat_ws(' ',cliente.apellidop,
    cliente.apellidom,
    cliente.nombre) as Nombre,
    cliente.rfc,
	concat_ws('. ',cliente.domicilio,cliente.colonia,cliente.municipio,'CP',cliente.cp) as Domicilio,
    cliente.id_cliente
From
    cliente
  where 1 $condicion 
ORDER BY
cliente.num_cliente desc";
 
	$lm->form_input_control['adjunto'] = '--document';	
	$lm->on_insert_validate['nombre'] = array('/.+/', 'Falta  tipo', 'Requerido'); 
	$lm->on_insert_validate['domicilio'] = array('/.+/', 'Falta  tipo', 'Requerido'); 
	$lm->on_insert_validate['colonia'] = array('/.+/', 'Falta  tipo', 'Requerido'); 
	$lm->on_insert_validate['municipio'] = array('/.+/', 'Falta  tipo', 'Requerido'); 
	$lm->on_insert_validate['telefono1'] = array('/.+/', 'Falta  tipo', 'Requerido'); 
//	$lm->on_insert_validate['num_cliente'] = array('/.+/', 'Falta  tipo', 'Requerido'); 	
		// optional, define what is displayed on edit form. identity id must be passed in also.  
	//	$lm->form_sql =  $_SESSION['var_sql_reporte'];
				
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
		
	//	echo $lm->grid_sql;
		// use the lm controller
		$lm->run();

function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama?o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.

global $lm;
$editable=false;

	$parametro=$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
?>
	
	<div class="md-card-content">
		<div class="uk-grid" data-uk-grid-margin="">	
			<div class="uk-width-medium-1-3 uk-row-first">
							<h3 class="heading_a">Datos Generales</h3>

								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Apellido Paterno</label>
										<?php imprimir($recordset["apellidop"],30);	?>
									</div>
									
								</div>	
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Apellido Materno</label>
										<?php imprimir($recordset["apellidom"],30);	?>
									</div>
									
								</div>								
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Nombre(s)</label>
										<?php imprimir($recordset["nombre"],30);	?>
									</div>
									
								</div>							
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>RFC</label>
										<?php imprimir($recordset["rfc"],30);?>
									</div>
									
								</div>	
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>CURP</label>
										<?php imprimir($recordset["curp"],30);?>
									</div>
									
								</div>		
								<div class="uk-form-row">
									<div class="md-input-wrapper">
										<label>Sexo (H)ombre (M)ujer</label>
										<?php imprimir($recordset["sexo"],30);?>
									</div>
									
								</div>									

			</div>
		<div class="uk-width-medium-1-3">
						<h3 class="heading_a">Domicilio del Cliente</h3>

                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Calle y número</label>
									<?php imprimir($recordset["domicilio"],30);	?>
								</div>
                                
                            </div>	
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Colonia</label>
									<?php imprimir($recordset["colonia"],30);	?>
								</div>
                                
                            </div>								
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Municipio</label>
									<?php imprimir($recordset["municipio"],30);	?>
								</div>
                                
                            </div>							
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>CP</label>
									<?php imprimir($recordset["cp"],30);?>
								</div>
                                
                            </div>	
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Telefono 1</label>
									<?php imprimir($recordset["telefono1"],30);?>
								</div>
                                
                            </div>
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Telefono 2</label>
									<?php imprimir($recordset["telefono2"],30);?>
								</div>
                                
                            </div>								

		</div>

		<div class="uk-width-medium-1-3">
						<h3 class="heading_a">Cliente SOFAYP</h3>

                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Num de cliente</label>
									<?php imprimir($recordset["num_cliente"],30);	?>
								</div>
                                
                            </div>
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Banco</label>
									<?php imprimir($recordset["banco"],30);	?>
								</div>
                                
                            </div>							
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Número de cuenta</label>
									<?php imprimir($recordset["num_cuenta_cliente"],30);	?>
								</div>
                                
                            </div>								
                            <div class="uk-form-row">
                                <div class="md-input">
									<label>Expediente (PDF)</label>
									<?php imprimir($recordset["adjunto"],30);	?>
								</div>
                                
                            </div>							
                            <div class="uk-form-row">
                                <div class="md-input-wrapper">
									<label>Anotaciones</label>
									<?php imprimir($recordset["anotaciones"],30);?>
								</div>
                                
                            </div>	
							

		</div>		
	</div>
</div>
		
 <?php
} // fin plantilla

?>


    </body>

    </html>