<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

	
<body>
<h4>Cruce de Tablas Capítulo 6000 y Reportes 5 al millar Finazas</h4>

	<?php
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
	//	$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
	

//ACTUALIZAMOS LAS FECHAS DE TEXTO A DATE EN LOS CAMPOS FECHA NULOS
$lm->query("update tabla_siox set fecha_pago=fecha_pago_txt where fecha_pago is null")	;
$lm->query("update tabla_siox set importe_total=importe_total_txt where importe_total is null")	;
$lm->query("update tabla_siox set importe_clave=importe_clave_txt where importe_clave is null")	;

		// table name for updates, inserts and deletes
		$lm->table = 'tabla_capitulo6000';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = false;
		// identity / primary key for table
		$lm->identity_name = 'id_detalle';
//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario);
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/

$lm->grid_limit = 10;

$query_tablas="Select
tabla_capitulo6000.id_detalle as id,
    tabla_finanzas.fecha as sefin_fecha,
    catalogo_ur.nombre_ur as sefin_ur,
	tabla_finanzas.clc as sefin_clc,
	format(tabla_finanzas.importe,2) as sefin_importe,
    
    tabla_finanzas.cve_conciliacion sefin_cve_conciliacion,
	date_format(tabla_capitulo6000.clc_fechaElaboracion,'%Y-%m-%d') as saso_fecha_clc,
    tabla_capitulo6000.clave_conciliacion as saso_cve_conciliacion,
    Format((tabla_capitulo6000.ncp_percepcionNeto / 1.16) * .005, 2) As 'saso_5_millar',
    tabla_capitulo6000.id_detalle
From
    tabla_capitulo6000 Inner Join
    tabla_finanzas On tabla_finanzas.clc = tabla_capitulo6000.clc_id Inner Join
    catalogo_ur On catalogo_ur.id_ur = tabla_finanzas.id_ur
            And catalogo_ur.clave_ur = tabla_capitulo6000.clave_ur
	where 1 $condicion";

$lm->grid_area_cols_size=40;
$lm->form_text_input_size=150;
$lm->grid_area_rows_size=5;

$lm->form_input_control['sefin_fecha']="--readonly";
$lm->form_input_control['sefin_ur']="--readonly";
$lm->form_input_control['sefin_importe']="--readonly";
$lm->form_input_control['sefin_cve_conciliacion']="--readonly";
$lm->form_input_control['saso_5_millar']="--readonly";

	
$lm->form_sql="Select
	
    tabla_finanzas.fecha as sefin_fecha,
    catalogo_ur.nombre_ur as sefin_ur,
	format(tabla_finanzas.importe,2) as sefin_importe,
    Format((tabla_capitulo6000.ncp_percepcionNeto / 1.16) * .005, 2) As 'saso_5_millar',
    tabla_finanzas.cve_conciliacion sefin_cve_conciliacion,
    tabla_capitulo6000.clave_conciliacion,
    Format((tabla_capitulo6000.ncp_percepcionNeto / 1.16) * .005, 2) As 'saso_5_millar',
    tabla_capitulo6000.id_detalle
From
    tabla_capitulo6000 Inner Join
    tabla_finanzas On tabla_finanzas.clc = tabla_capitulo6000.clc_id Inner Join
    catalogo_ur On catalogo_ur.id_ur = tabla_finanzas.id_ur
            And catalogo_ur.clave_ur = tabla_capitulo6000.clave_ur
	where  id_detalle = :id_detalle";
		
		// optional, define input controls on the form
		//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';
// optional, define editable input controls on the grid
		//$lm->form_input_control['is_active'] = "select 1, 'Yes' union select 0, 'No' union select 2, 'Maybe'; --radio";
			

		$lm->grid_sql = $query_tablas;
		
	
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
		
		//echo $lm->grid_sql;
		// use the lm controller
		$lm->run();
//}

?>	

<script>
<?php echo $JavaScript; ?>
</script>
 <script src="assets/libs/jquery/dist/jquery.min.js"></script>
	<!--SELECT 2 CSS / JS-->
	<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
		$('.js-example-placeholder-single').select2({
		placeholder: "Buscar y seleccionar...",
		width: '50%',
   	 	allowClear: true });
	});
	</script>
	<!--END SELECT 2 CCS / JS-->

	
    </body>

    </html>