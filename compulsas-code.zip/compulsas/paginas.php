<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>


    <body>
	
        <h4>Páginas del Sistema</h4>


					
<script>
	function MuestraModal(nombre) {
	document.getElementsByName('modal-frame')[0].src = nombre;
}
</script>		
        <?php
try {
    $dbh = new PDO("mysql:host=" . LM_HOSTNAME . ";dbname=" . LM_NAME . ";charset=utf8", LM_USERNAME, LM_PASSWORD);
}
catch(PDOException $e) {
    die('pdo connection error: ' . $e->getMessage());
}
// create LM object, pass in PDO connection

$lm = new lazy_mofo($dbh);
// create LM object, pass in PDO connection
// table name for updates, inserts and deletes
$lm->table = 'pagina';
$lm->identity_name = 'id_pagina';
$lm->return_to_edit_after_insert = false;
$lm->return_to_edit_after_update = true;
// identity / primary key for table


//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario);
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/

$query_paginas = "SELECT
 pagina.id_pagina as ID,
  pagina.pagina,
  pagina.nombre,
  pagina.icono,
  pagina.id_grupomenu,
  
  pagina.id_pagina
FROM
  pagina where 1 $condicion
  order by pagina.id_pagina desc";  

$lm->grid_limit = 10;
$lm->grid_sql = $query_paginas;
//echo $lm->grid_sql;
$lm->form_custom_template = true; // SE ESPECIFICA QUE HAY UNA PLAN
// optional, define what is displayed on edit form. identity id must be passed in also.
$lm->form_sql = "SELECT
  pagina.pagina,
  pagina.nombre,
   pagina.icono,
   pagina.id_grupomenu,
   pagina.orden_opcion,
    pagina.ocultar_en_panel,
  pagina.id_pagina
FROM
  pagina  where id_pagina = :id_pagina ";
  
  		$lm->form_input_control['id_grupomenu'] = "SELECT
  grupomenu.id_grupomenu,
  grupomenu.nombre_grupo
FROM
  grupomenu
ORDER BY
  grupomenu.nombre_grupo; --select";
  
    		$lm->grid_input_control['id_grupomenu'] = "SELECT
  grupomenu.id_grupomenu,
  grupomenu.nombre_grupo
FROM
  grupomenu
ORDER BY
  grupomenu.nombre_grupo; --select";
  
  $lm->form_input_control['ocultar_en_panel'] = '--checkbox';
  
      		$lm->grid_input_control['orden_opcion'] = "--number";
  
  
$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name];
$_SESSION['Tempo_Pagina']=$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
// use the lm controller

$lm->run();
//}
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama?o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.

?>

						
<div class="md-card-content">
                    <div class="uk-grid">
                        <div class="uk-width-1-1">
<!-- Nav tabs -->

						    <ul class="nav nav-tabs customtab" role="tablist">
							<li class="nav-item"><a class="nav-link" href="#">Ajustes-></a></li>
                                 <li class="nav-item">
									<a  class="nav-link" data-toggle="modal" data-target=".bs-example-modal-lg" onclick="MuestraModal('subform_filtros.php')" role="tab"><span class="hidden-sm-up"><span>Filtros</span></a>
								</li>
                                 <li aria-expanded="false" class="">
									<a class="nav-link"data-toggle="modal" data-target=".bs-example-modal-lg"  onclick="MuestraModal('subform_permisos.php')" role="tab"><span class="hidden-sm-up"><span>Permisos</span></a>								
								</li>
                                 <li aria-expanded="false" class="">
									<a  class="nav-link"data-toggle="modal" data-target=".bs-example-modal-lg"  onclick="MuestraModal('subform_parametros.php')" role="tab"><span class="hidden-sm-up"><span>Parametros</span></a>						
								</li>
                            </ul>
                        <table>
                            <tbody>
                                <tr>
                                    <th colspan="2">
                                        <?php imprimir($recordset["lm_accion"],60);
				?>
                                    </th>
                                </tr>
                                <tr>
                                    <td>Nombre de P&aacute;gina </td>
                                    <td>
                                        <?php imprimir($recordset["pagina"],30);
				?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Nombre en Men&uacute; </td>
                                    <td>
                                        <?php imprimir($recordset["nombre"],30);
				?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Icono</td>
                                    <td>
                                        <?php imprimir($recordset["icono"],30);
				?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Grupo Menu</td>
                                    <td>
                                        <?php imprimir($recordset["id_grupomenu"],30);
				?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Ocultar en Panel Menu</td>
                                    <td>
                                        <?php imprimir($recordset["ocultar_en_panel"],30);
				?>
                                    </td>
                                </tr>								

                            </tbody>
                        </table>								

                        </div>
                    </div>
                </div>
				


 <?php
} // fin plantilla

?>

		<div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <!-- sample modal content -->
                                <div class="modal bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger waves-effect text-left" data-dismiss="modal">Cerrar</button>
                                            </div>
<iframe name='modal-frame' src='' style='border: 1' width='100%' height='400px' frameborder='1' scrolling='yes'></iframe>

                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- /.modal -->
                                
                            </div>
                        </div>
                    </div>

<script>
	function myFunction2() {
	document.getElementById("botonfiltro").click()
	}
</script>

<script>
<?php echo $JavaScript; ?>
</script>

   <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <script src="dist/js/app.min.js"></script>
    <script src="dist/js/app.init.js"></script>
    <script src="dist/js/app-style-switcher.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
   <script src="dist/js/feather.min.js"></script>
    <script src="dist/js/custom.min.js"></script>
	
</body>
</html>