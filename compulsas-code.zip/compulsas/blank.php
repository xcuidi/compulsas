<?php
session_start();  
if (!isset($_SESSION['Usuario'])) {
    session_destroy(); // destruyo la sesión
    header("Location: expired.php");
}
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');


		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
$lm = new lazy_mofo($dbh); 

$id_usuario=$_SESSION['SesIdUsuario'];
$interno_total="SELECT
  count(seg_interno.id_correspondencia) as cantidad from seg_interno  where seg_interno.id_usuario=$id_usuario
  and seg_interno.id_estatus_seg <> 1";
  $dato_3=$lm->query($interno_total);
	$valor_3=$dato_3[0]['cantidad'];

$interno_atendidos="SELECT
  count(seg_interno.id_correspondencia) as cantidad from seg_interno  where seg_interno.id_usuario=$id_usuario
  and seg_interno.id_estatus_seg = 1";
    $dato_4=$lm->query($interno_atendidos);
	$valor_4=$dato_4[0]['cantidad'];

$control_doc="SELECT
  count(control_documento.id_control) as cantidad from control_documento  where control_documento.id_usuario=$id_usuario
  and control_documento.estatus = 2 ";
    $dato_5=$lm->query($control_doc);
	$valor_5=$dato_5[0]['cantidad'];
  
 $query_avisos="SELECT
 * from aviso  
 where
    datediff(fecha_vigencia,now())>=0 ";
 

?>
<!DOCTYPE html>
    <html lang="es">

<head>
<!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
     <![endif]-->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/main.css">
<script type="text/javascript" src="bower_components/tether/dist/js/tether.min.js"></script>

   <!-- owl carousel css -->
   <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="bower_components/swiper/dist/css/swiper.min.css">

   
   
</head>

<body>
<h4>Bienvenido</h4>

						<div class="row">
								<div class='main-card mb-3 card'>
									<div class="card-block">
										<h6 class="sub-title">Avisos</h6>
										<ul class="basic-list list-icons">
										<?php 
										 foreach ($dbh->query($query_avisos) as $row)
                                { ?>
											<li>
												<i class="icofont icofont-bell-alt txt-primary p-absolute text-center d-block f-30"></i>
												<h6><?=$row['encabezado']?></h6>
												<p> <?=$row['txt_aviso']?></p>
												<?php if($row['link'] != NULL) { ?>
												<a href="<?=$row['link']?>" target='_blank' class="card-link">Enlace relacionado</a>
												<?php }
													if($row['adjunto'] != NULL) {?>
													<a href="uploads/<?=$row['adjunto']?>" target='_blank' class="card-link">Documento relacionado</a>	
												<?php }?>										
											</li>
								<?php } ?>	
										</ul>
									</div>
								</div>
									
							
						</div>
						
			<div class="row">
                    <div class="col-lg-3 col-md-4">
                        <div class="card dashboard-product">
                            <span>Correspondencia recibida</span>
                            <h2 class="dashboard-total-products"><span><?=$valor_3;?></span></h2>
                            <span class="label label-danger">Folios internos</span>Sin seguimiento
                            <div class="side-box">
                                <i class="ti-direction-alt text-danger-color"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <div class="card dashboard-product">
                            <span>Correspondencia recibida</span>
                            <h2 class="dashboard-total-products"><?=$valor_4;?></h2>
                            <span class="label label-primary">Folios internos</span>Atendidos
                            <div class="side-box ">
                                <i class="ti-gift text-primary-color"></i>
                            </div>
                        </div>
                    </div>					
                    <div class="col-lg-3 col-md-4">
                        <div class="card dashboard-product">
                            <span>Minutario</span>
                            <h2 class="dashboard-total-products"><span><?=$valor_5;?></span></h2>
                            <span class="label label-danger">Documentos</span>Sin seguimiento
                            <div class="side-box">
                                <i class="ti-rocket text-danger-color"></i>
                            </div>
                        </div>
                    </div>
            </div>
			
			
<div class="row">			   
<?php if ($_SESSION['Redes_Sociales']==1) { ?>
	<div class="col-lg-6">
	
	<a class="twitter-timeline" href="https://twitter.com/SAPAO_GobOax?ref_src=twsrc%5Etfw">Tweets by SAPAO_GobOax</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

	</div>
	<?php }	?>	
	<div class="col-lg-6">
<div class="card">
			
	<a href="gaceta/gaceta.pdf" target='_blank'>
    <div class="card-header">
        <h5 class="card-header-text">Gaceta Informativa SAPAO</h5>
        <p></p>
    </div>
    <div class="card-block">
        <div id="bs4-carousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#bs4-carousel" data-slide-to="0" class="active"></li>
                <li data-target="#bs4-carousel" data-slide-to="1"></li>
              
            </ol>
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                    <img src="gaceta/portada1.png" alt="First slide" class="img-fluid" />

                </div>
                <div class="carousel-item">
                    <img src="gaceta/portada2.png" alt="Second slide" />

                </div>

            </div>
		
        </div>
    </div>
	</a>
</div>



		</div>
    <!-- end of row -->
	</div>

</div>




</body>
</html>