<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
<body>
<h4>Tablas para importar datos</h4>

	<?php
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
	//	$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'tablas_sefip';

//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario,'M');
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id';

		 $lm->grid_extra_link2 = "<a href=\"importarxls/importar_excel.php?id_tabla=[identity_id]\" target=\"_blank\">[Importar]</a>";
$query_tablas="Select
    tablas_sefip.nombre_tabla,
    tablas_sefip.descripcion,
    tablas_sefip.id
From
    tablas_sefip where 1 $condicion";

$lm->grid_area_cols_size=40;
$lm->form_text_input_size=150;
$lm->grid_area_rows_size=5;


		
		// optional, define input controls on the form
		//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';
// optional, define editable input controls on the grid
		//$lm->form_input_control['is_active'] = "select 1, 'Yes' union select 0, 'No' union select 2, 'Maybe'; --radio";
			

		$lm->grid_sql = $query_tablas;
	
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	
		// use the lm controller
		$lm->run();
//}

?>	


               
    </body>

    </html>