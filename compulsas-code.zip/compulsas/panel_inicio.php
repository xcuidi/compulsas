<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML

	try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
?>
	
<body>
	
<?php 	
 $query_avisos="SELECT
 * from aviso  
 where
    datediff(fecha_vigencia,now())>=0 "; 

										$x=1;
										 foreach ($dbh->query($query_avisos) as $row)
                                { 
									if($x==1) {?>
        <div class="md-card">
            <div class="md-card-content">
			
							<div class="md-card-toolbar">
								<h3 class="heading_a">Avisos</h3>
							</div>
										<ul class="md-list">
									<?php } ?>
											<li>
												<div class="md-list-content">
													<span class="md-list-heading"><?=$row['encabezado']?></span>
												<span class="uk-text">
												<?php echo str_replace("\n", "<br>", $row['txt_aviso']) ?>
												</span>
												
												<?php if($row['link'] != NULL) { ?>
												<div class="md-list-content">
												<span class="md-list-heading">
												<a href="<?=$row['link']?>" target='_blank' class="md-btn md-btn-primary md-btn-mini md-btn-wave-light md-btn-icon waves-effect waves-button waves-light"><i class="uk-icon-link"></i></a> 
												<?php }
													if($row['adjunto'] != NULL) {?>
													
													<a href="uploads/<?=$row['adjunto']?>" target='_blank' class="md-btn md-btn-primary md-btn-mini md-btn-wave-light md-btn-icon waves-effect waves-button waves-light"><i class="uk-icon-paperclip"></i></a>	</span>
												</div>
												<?php }?>	
												</div>
											</li>
								<?php  $x++; }?>	
										</ul>
						
			</div>
		</div>

<div class="md-card">
    <div class="md-card-content">

			<div class="uk-grid uk-grid-width-large-1-4 uk-grid-width-medium-1-2 uk-grid-medium uk-sortable"  data-uk-grid-margin="">


			
                <div class="" style="">
                    <div class="md-card">
                        <div class="md-card-content">
                            
                            <span class="uk-text-muted uk-text-small">Estadistica 1</span>
                            <h2 class="uk-margin-remove"><span class="countUpMe">#</span></h2>
                        </div>
                    </div>
                </div>
				
                <div class="" style="">
                    <div class="md-card">
                        <div class="md-card-content">
                            
                            <span class="uk-text-muted uk-text-small">Estadística 2</span>
                            <h2 class="uk-margin-remove"><span class="countUpMe">#</span></h2>
                        </div>
                    </div>
                </div>	
                <div style="">
                    <div class="md-card">
                        <div class="md-card-content">
                            
                            <span class="uk-text-muted uk-text-small">Estadística 3</span>
                            <h2 class="uk-margin-remove"><span class="countUpMe">#</span></h2>
                        </div>
                    </div>
                </div>				
            </div>

	</div>
</div>


</body>
</html>