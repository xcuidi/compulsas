<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');
?>

    <!doctype html>
    <html lang="es">

    <head>
        <!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
     <![endif]-->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/main.css">
        <script type="text/javascript" src="bower_components/tether/dist/js/tether.min.js"></script>

        <!-- FOO TABLES -->
        <link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="bower_components/footable/compiled/footable.bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/plugins/foo-table/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="bower_components/footable/compiled/footable.standalone.min.css">
        <!-- /FOO TABLES-->

    </head>
<body>
                                <h4>Permisos de usuarios</h4>
	<?php

		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
		//$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'perfil';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_perfil';
	
//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario);
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/

 $query_menup="SELECT
  mnu.nombre AS Menu,
  pagina.pagina,
  perfil.nuevo,
  perfil.modificar,
  perfil.eliminar,
  perfil.excel,
  perfil.id_perfil
FROM
  perfil
  INNER JOIN mnu ON mnu.id_mnu = perfil.id_mnu
  INNER JOIN pagina ON pagina.id_pagina = perfil.id_pagina
   
  where 1 $condicion 
ORDER BY
  mnu.nombre,
  perfil.id_pagina desc";
$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=15;
	
	
$lm->grid_input_control['nuevo'] = '--checkbox';
$lm->grid_input_control['modificar'] = '--checkbox';
$lm->grid_input_control['eliminar'] = '--checkbox';
$lm->grid_input_control['excel'] = '--checkbox';


$lm->form_input_control['nuevo'] = '--checkbox';
$lm->form_input_control['modificar'] = '--checkbox';
$lm->form_input_control['eliminar'] = '--checkbox';
$lm->form_input_control['excel'] = '--checkbox';

$lm->form_input_control['vista'] = '--checkbox';
$lm->form_input_control['buscar'] = '--checkbox';
$lm->form_input_control['html'] = '--checkbox';


//	$lm->grid_input_control['vista'] = "SELECT   'S' as opcion, 'S' as decrip UNION SELECT   'N' as opcion, 'N' as decrip ; --select"; 
//	$lm->grid_input_control['buscar'] = "SELECT   'S' as opcion, 'S' as decrip  UNION SELECT   'N' as opcion, 'N' as decrip ; --select";



     $lm->form_input_control['id_mnu_detp'] = "SELECT
  id_mnu_detp, etiqueta from
mnu_detp where 1
  order by etiqueta ; --select"; 
  $lm->form_default_value['activo']=1;
   $lm->form_default_value['nuevo']=0;
   $lm->form_default_value['modificar']=0;
    $lm->form_default_value['eliminar']=0;
	 $lm->form_default_value['vista']=0;
	  $lm->form_default_value['buscar']=0;
	   $lm->form_default_value['html']=0;
	    $lm->form_default_value['excel']=0;
  
  $lm->form_input_control['activo'] = '--checkbox';
    $lm->grid_input_control['activo'] = '--checkbox';
  
 
      $lm->form_input_control['id_pagina'] = "SELECT
  id_pagina, concat(nombre, ' | ',pagina) as nombre from
 pagina
  order by nombre ; --select";  
  
		$lm->form_input_control['id_mnu'] = "SELECT
  id_mnu, nombre from
  mnu where 1
  order by nombre ; --select";
  //''''''''''''	
		// optional, make friendly names for fields
		
	//	$lm->rename['usuario_activo'] = 'Activo';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		
		$lm->form_input_control['id_mnu_detp'] = "SELECT
  mnu_detp.id_mnu_detp,
  
  Concat(mnu.nombre,' > ',mnu_detp.id_mnu_detp, ' - ', mnu_detp.etiqueta) AS c2
FROM
  mnu_detp
  INNER JOIN mnu ON mnu.id_mnu = mnu_detp.id_mnu
ORDER BY
  mnu.id_mnu, mnu_detp.orden_menu, mnu_detp.etiqueta; --select";
		

	$lm->form_input_control['id_pagina'] = "SELECT
  pagina.id_pagina,
  Concat(pagina.nombre, ' | ', pagina.pagina) AS c2
FROM
  pagina order by pagina.nombre; --select";
		
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid
		
			// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		
	  $lm->form_sql = 'select id_perfil, id_mnu, id_pagina from perfil where id_perfil = :id_perfil';
	$lm->form_sql_param = array(":id_perfil" => @$_REQUEST['id_perfil']); 
		$lm->grid_sql = $query_menup;
	//	echo "R: ",$_SESSION['Where_Region']," D: ",$_SESSION['Where_Diocesis']," S: ", $_SESSION['Where_Sector'], " ROL: ", $_SESSION['Where_Rol'], " N: ",$_SESSION['Where_Nivel'],"<br>";
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
			
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	//	$lm->form_default_value['condicion']=array(' where 1' );
		
		
		// use the lm controller
		$lm->run();
//}
	
								
	
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama?o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
?>
<table>
  <tr>
    <th colspan="2"><?php imprimir($recordset["lm_accion"],60);
			?></th>
  </tr>
  <tr>
    <td>Menu Padre </td>
    <td><?php imprimir($recordset["id_mnu"],20);
			?></td>
  </tr>
  <tr>
    <td width="166">Opci&oacute;n</td>
    <td width="398"><?php imprimir($recordset["id_pagina"],20);
			?></td>
  </tr>
  <tr>
    <td>Activo</td>
    <td><?php imprimir($recordset["activo"],80);
			?></td>
  </tr>
</table>
 <?php
} // fin plantilla

?>

        

                <script>
                    <?php echo $JavaScript; ?>
                </script>
    </body>

    </html>
