<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
<body>

	<?php
 $query_perfil="Select
    perfil_query.id_reporte,
    mnu.nombre As Menu,
    usuario.nombre As usuario,
    
    perfil_query.nuevo,
    perfil_query.modificar,
    perfil_query.eliminar,
    perfil_query.excel,
    perfil_query.id_perfil
From
    perfil_query Left Join
    mnu On mnu.id_mnu = perfil_query.id_mnu Left Join
    usuario On usuario.id_usuario = perfil_query.id_usuario WHERE id_reporte=".$_SESSION['Tempo_Reporte']."
ORDER BY
  mnu.id_mnu desc";
		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		
		$lm->primary_form=false; // Indicamos que no es un formulario principal
		
		// create LM object, pass in PDO connection
		//$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'perfil_query';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_perfil';
	

	$lm->timezone='Mexico/General';
$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=15;
	
	
$lm->grid_input_control['nuevo'] = '--checkbox';
$lm->grid_input_control['modificar'] = '--checkbox';
$lm->grid_input_control['eliminar'] = '--checkbox';
$lm->grid_input_control['excel'] = '--checkbox';


$lm->form_input_control['nuevo'] = '--checkbox';
$lm->form_input_control['modificar'] = '--checkbox';
$lm->form_input_control['eliminar'] = '--checkbox';
$lm->form_input_control['excel'] = '--checkbox';

$lm->form_input_control['vista'] = '--checkbox';
$lm->form_input_control['buscar'] = '--checkbox';
$lm->form_input_control['html'] = '--checkbox';


  $lm->form_default_value['id_reporte']=$_SESSION['Tempo_Reporte'];
  $lm->form_default_value['activo']=1;
   $lm->form_default_value['nuevo']=0;
   $lm->form_default_value['modificar']=0;
    $lm->form_default_value['eliminar']=0;
	 $lm->form_default_value['vista']=0;
	  $lm->form_default_value['buscar']=0;
	   $lm->form_default_value['html']=0;
	    $lm->form_default_value['excel']=0;
  
  
    $lm->form_input_control['id_mnu'] = "SELECT
  mnu.id_mnu,
  mnu.nombre
FROM
  mnu
ORDER BY
  mnu.nombre ; --select";  
  

$lm->form_input_control['id_usuario'] = "SELECT
  usuario.id_usuario,
  usuario.nombre
FROM
  usuario order by usuario.nombre and usuario.usuario_activo=1; --select2";	 		
  //''''''''''''	
		// optional, make friendly names for fields
		
	//	$lm->rename['usuario_activo'] = 'Activo';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		

		

	
		
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid
		
			
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		
	  $lm->form_sql = 'select id_perfil, id_reporte, id_mnu, id_usuario from perfil_query where id_perfil = :id_perfil';
	$lm->form_sql_param = array(":id_perfil" => @$_REQUEST['id_perfil']); 
		$lm->grid_sql = $query_perfil;

	//	echo $lm->grid_sql;
	
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
			
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	//	$lm->form_default_value['condicion']=array(' where 1' );
		
		
		// use the lm controller
		$lm->run();
//}
	
								
?>

 	<!--SELECT 2 CSS / JS-->
	<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
		$('.js-example-placeholder-single').select2({
		placeholder: "Buscar y seleccionar...",
   	 	allowClear: true });
	});
	</script>
	
	<!--END SELECT 2 CCS / JS-->
 
</body>
</html>