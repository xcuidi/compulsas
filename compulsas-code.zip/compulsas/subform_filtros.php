<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');
// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

<body>

	<?php
 
		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		$lm = new lazy_mofo($dbh); 
		$lm->primary_form=false; // Indicamos que no es un formulario principal
	
	$query_paginas="SELECT
 filtros.id as ID_Filtro,
 filtros.orden_filtro,
  filtros.type,
 filtros.name,
  filtros.size,
  filtros.placeholder,
  filtros.id
FROM
  filtros 
  where filtros.id_pagina=".$_SESSION['Tempo_Pagina']."
  order by filtros.orden_filtro";
//$Where_filtros['Filtro'] 
		
		
		// table name for updates, inserts and deletes
		$lm->table = 'filtros';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id';

$lm->grid_area_cols_size=20;
$lm->grid_area_rows_size=5;

	$lm->form_default_value['id_pagina']=$_SESSION['Tempo_Pagina'];

	$lm->form_custom_template = true; // SE ESPECIFICA QUE HAY UNA PLAN	

  $lm->form_input_control['type'] = "Select
    catalogo.valor,
    catalogo.descripcion,
    catalogo.tipo
From
    catalogo
Where
    catalogo.tipo = 'DATA_TYPE'; --select";	
	
  $lm->form_input_control['filtro_ubicacion'] = "Select
    catalogo.valor,
    catalogo.descripcion,
    catalogo.tipo
From
    catalogo
Where
    catalogo.tipo = 'FILTRO_UBICACION'; --select";		
	
		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid
		

		
		
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		
		
		$lm->grid_sql = $query_paginas;
	//	echo "R: ",$_SESSION['Where_Region']," D: ",$_SESSION['Where_Diocesis']," S: ", $_SESSION['Where_Sector'], " ROL: ", $_SESSION['Where_Rol'], " N: ",$_SESSION['Where_Nivel'],"<br>";
//		echo $lm->grid_sql;

		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	//	$lm->form_default_value['condicion']=array(' where 1' );
		
		
		// use the lm controller
		$lm->run();
//}
	
								
	
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama?o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
?>
<table cellspacing="3" class="table table-bordered" >

  <tr>
    <td>Página*</td>
    <td><?php imprimir($recordset["id_pagina"],30);
			?></td>
    <td>Orden</td>
    <td><?php imprimir($recordset["orden_filtro"],30);
			?></td>
  </tr>
  <tr>
    <td>Tipo Dato </td>
    <td><?php imprimir($recordset["type"],30);
			?></td>
    <td>Nombre campo </td>
    <td><?php imprimir($recordset["name"],30);
			?></td>
  </tr>
  <tr>
    <td>Tama&ntilde;o</td>
    <td><?php imprimir($recordset["size"],30);
			?></td>
    <td>Placeholder</td>
    <td><?php imprimir($recordset["placeholder"],30);
			?></td>
  </tr>

  <tr>
    <td>Sql Combo </td>
    <td colspan="3"><?php imprimir($recordset["combo_query"],30);
			?></td>
  </tr>
  <tr>
    <td>Id Combo </td>
    <td><?php imprimir($recordset["campo_id_combo"],30);
			?></td>

  </tr>
</table>

 <?php
} // fin plantilla

?>


 
</body>
</html>
