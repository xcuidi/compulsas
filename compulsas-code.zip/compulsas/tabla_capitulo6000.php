<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

	
<body>

<h4>Tabla Capítulo 6000</h4>

<script>
	function MuestraModal(nombre) {
	document.getElementsByName('modal-frame')[0].src = nombre;
}
</script>	

	<?php
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
		$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
	

//ACTUALIZAMOS LAS FECHAS DE TEXTO A DATE EN LOS CAMPOS FECHA NULOS
//$lm->query("update tabla_finanzas set fecha=fecha_txt where fecha is null")	;
//$lm->query("update tabla_finanzas set importe=importe_txt where importe is null")	;
		// table name for updates, inserts and deletes
		$lm->table = 'tabla_capitulo6000';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = false;
		// identity / primary key for table
		$lm->identity_name = 'id_detalle';
//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario);
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/

$lm->grid_limit = 10;

$query_tablas="Select
    tabla_capitulo6000.clc_beneficiario,
	concat_ws('|',tabla_capitulo6000.cfi_clave,tabla_capitulo6000.fondo_programa) as 'cfi|fondo',
    tabla_capitulo6000.mpc_nombre,
    tabla_capitulo6000.clc_concepto,
	tabla_capitulo6000.clc_id,
	tabla_capitulo6000.referencia,
    format(tabla_capitulo6000.ncp_percepcionNeto,2) as ncp_percepcionNeto,
    format((tabla_capitulo6000.ncp_percepcionNeto/1.16)*.005,2) as 'Est_5_millar',
    tabla_capitulo6000.oa_numObra,
	tabla_capitulo6000.clave_conciliacion,
    tabla_capitulo6000.id_detalle
   
From
    tabla_capitulo6000
	where 1 $condicion";

$lm->grid_area_cols_size=40;
$lm->form_text_input_size=150;
$lm->grid_area_rows_size=5;


	
$lm->form_input_control['presupuesto']="--readonly";
$lm->form_input_control['partida_descripcion']="--readonly";
$lm->form_input_control['referencia']="--readonly";
$lm->form_input_control['lot_fechaPago']="--readonly";
$lm->form_input_control['fondo_programa']="--readonly";
$lm->form_input_control['oa_numObra']="--readonly";
$lm->form_input_control['clc_concepto']="--readonly";


		
		// optional, define input controls on the form
		//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';
// optional, define editable input controls on the grid
		//$lm->form_input_control['is_active'] = "select 1, 'Yes' union select 0, 'No' union select 2, 'Maybe'; --radio";
			

		$lm->grid_sql = $query_tablas;
		
	
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
		
		//echo $lm->grid_sql;
		// use the lm controller
		$lm->run();
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama?o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
global $lm;
$editable=true;
$nuevo_registro=true;
$activa='active';	
$parametro=$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 

	$_SESSION['Tempo_Lista']=$parametro;
if ($recordset["lm_accion"]=="Editar") {	

	$registro=$lm->query("Select
    tabla_capitulo6000.EJECUTOR,
    tabla_capitulo6000.UR,
	tabla_capitulo6000.clave_ur,
	tabla_capitulo6000.rfc_id,
	tabla_capitulo6000.oa_numObra,
    format(tabla_capitulo6000.ncp_percepcionNeto,2) as ncp_percepcionNeto,
    format((tabla_capitulo6000.ncp_percepcionNeto/1.16)*.005,2) as 'Est_5_millar'
From
    tabla_capitulo6000 
	where id_detalle=$parametro"); 
	
	$_SESSION['Tempo_UR']=$registro[0]['clave_ur'];
	$_SESSION['Tempo_RFC']=$registro[0]['rfc_id'];
	$_SESSION['Tempo_oficio_autorizacion']=$registro[0]['oa_numObra'];

}
?>

						
<div class="md-card-content">
                    <div class="uk-grid">
                        <div class="uk-width-1-1">
<!-- Nav tabs -->

						    <ul class="nav nav-tabs customtab" role="tablist">
							<li class="nav-item"><a class="nav-link" href="#">Capitulo 6000-></a></li>
                                 <li class="nav-item">
									<a  class="nav-link" data-toggle="modal" data-target=".bs-example-modal-lg" onclick="MuestraModal('subform_reporte_ingresos.php?buscar=ur')" role="tab"><span class="hidden-sm-up"><span>Buscar Clave por UR</span></a>
								</li>
                                 <li class="nav-item">
									<a  class="nav-link" data-toggle="modal" data-target=".bs-example-modal-lg" onclick="MuestraModal('subform_reporte_ingresos.php?buscar=rfc')" role="tab"><span class="hidden-sm-up"><span>Buscar Clave por RFC</span></a>
								</li>
                                 <li class="nav-item">
									<a  class="nav-link" data-toggle="modal" data-target=".bs-example-modal-lg" onclick="MuestraModal('subform_reporte_ingresos.php?buscar=oa')" role="tab"><span class="hidden-sm-up"><span>Buscar Clave por Oficio de autorizacion</span></a>
								</li>								
							</li>
                            </ul>
 
<table class="table table-striped table-bordered">
  <tr>
    <td width="26%">Clave Conciliaci&oacute;n </td>
    <td width="27%">Presupuesto</td>
    <td width="20%">Est. 5 al millar </td>
    <td width="27%">Partida descripcion </td>
  </tr>
  <tr>
    <td><?php imprimir($recordset["clave_conciliacion"],30);	?></td>
    <td><?php imprimir($recordset["presupuesto"],30);	?></td>
    <td><?php echo $registro[0]['Est_5_millar']; ?></td>
    <td><?php imprimir($recordset["partida_descripcion"],30);	?></td>
  </tr>
  <tr>
    <td>Referencia</td>
    <td>Fecha pago </td>
    <td>Fondo programa </td>
    <td>Num Obra / Of. Aut </td>
  </tr>
  <tr>
    <td><?php imprimir($recordset["referencia"],30);	?></td>
    <td><?php imprimir($recordset["lot_fechaPago"],30);	?></td>
    <td><?php imprimir($recordset["fondo_programa"],30);	?></td>
    <td><?php imprimir($recordset["oa_numObra"],30);	?></td>
  </tr>

  <tr>
    <td>Clc Concepto </td>
    <td colspan="3"><?php imprimir($recordset["clc_concepto"],30);	?></td>
  </tr>
  <!--
      <tr>
  
    <td colspan="4">BUSQUEDAS EN LA TABLA REPORTE DE INGRESOS</td>
  </tr>
 
    <tr>
  
    <td colspan="4"><iframe name='modal-frame' src='subform_reporte_ingresos.php' style='border: 1' width='100%' height='400px' frameborder='1' scrolling='yes'></iframe></td>
  </tr>
   -->
</table>

<p>&nbsp;</p>
								

                        </div>
                    </div>
                </div>
				


 <?php
} // fin plantilla

?>

		<div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <!-- sample modal content -->
                                <div class="modal bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger waves-effect text-left" data-dismiss="modal">Cerrar</button>
                                            </div>
<iframe name='modal-frame' src='' style='border: 1' width='100%' height='400px' frameborder='1' scrolling='yes'></iframe>

                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- /.modal -->
                                
                            </div>
                        </div>
                    </div>

<script>
	function myFunction2() {
	document.getElementById("botonfiltro").click()
	}
</script>

<script>
<?php echo $JavaScript; ?>
</script>


<script>
<?php echo $JavaScript; ?>
</script>
 <script src="assets/libs/jquery/dist/jquery.min.js"></script>
	<!--SELECT 2 CSS / JS-->
	<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
		$('.js-example-placeholder-single').select2({
		placeholder: "Buscar y seleccionar...",
		width: '50%',
   	 	allowClear: true });
	});
</script>
	<!--END SELECT 2 CCS / JS-->
	
   <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <script src="dist/js/app.min.js"></script>
    <script src="dist/js/app.init.js"></script>
    <script src="dist/js/app-style-switcher.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
   <script src="dist/js/feather.min.js"></script>
    <script src="dist/js/custom.min.js"></script>
	
</body>
</html>
