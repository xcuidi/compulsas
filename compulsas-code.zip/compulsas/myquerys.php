<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>


    <body>
	
        <h4>Generador de reportes</h4>

					
<script>
	function MuestraModal(nombre) {
	document.getElementsByName('modal-frame')[0].src = nombre;
}
</script>	
        <?php

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}

		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
		$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO


//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario);
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/

		// table name for updates, inserts and deletes
		$lm->table = 'reporte';

		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_reporte';

$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=10;

$condicion2="";
if ($_SESSION['SesGrupo']!=1) {
	$condicion2=" and tipo_reporte <> 'SYS' ";	
}
	 $query_reportes="SELECT
 reporte.id_reporte as Id,

  reporte.nombre_reporte,
  reporte.tabla,
   reporte.identificador,
   reporte.tipo_reporte,
   reporte.nombre_menu as Menu_Extra,
   concat( reporte.nombre_opcion, ' | ',reporte.orden_opcion) as Opcion_Extra,

   reporte.id_reporte
FROM
  reporte
		where 1 $condicion2 $condicion  order by tipo_reporte, nombre_reporte ";

		// optional, make friendly names for fields

		//$lm->rename['nombres'] = 'Nombres';
		//$lm->rename['fechanacimiento'] = 'Fecha';

		// optional, define input controls on the form
		//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';
// optional, define editable input controls on the grid
		//$lm->form_input_control['is_active'] = "select 1, 'Yes' union select 0, 'No' union select 2, 'Maybe'; --radio";
		$lm->form_input_control['puede_borrar'] = '--checkbox';
		$lm->form_input_control['puede_agregar'] = '--checkbox';
		$lm->form_input_control['puede_editar'] = '--checkbox';
		$lm->form_input_control['sqlquery'] = '--textarea';
		$lm->on_insert_validate['tabla'] = array('/.+/', 'Falta  Tabla', 'Requerido'); 
		$lm->on_insert_validate['identificador'] = array('/.+/', 'Falta  Identificador', 'Requerido'); 
		$lm->on_insert_validate['tipo_reporte'] = array('/.+/', 'Falta  Tipo de reporte', 'Requerido'); 

		$lm->form_input_control['tipo_reporte'] = 'SELECT   tipo_reporte.tipo,   tipo_reporte.descripcion FROM   tipo_reporte --select';

		$lm->date_out = 'd/m/Y';
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid

	//	$lm->grid_show_search_box = true;

		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear

		$lm->grid_sql = $query_reportes;

	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';

		// optional, define what is displayed on edit form. identity id must be passed in also.  

		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	//	$lm->form_default_value['condicion']=array(' where 1' );
		$_SESSION['Tempo_Reporte']=$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 

		// use the lm controller
		$lm->run();
//}

function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama?o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
?>

<div class="md-card-content">
                    <div class="uk-grid">
                        <div class="uk-width-1-1">


						    <ul class="nav nav-tabs customtab" role="tablist">
							<li class="nav-item"><a class="nav-link" href="#">Ajustes-></a></li>
                                 <li class="nav-item">
									<a  class="nav-link" data-toggle="modal" data-target=".bs-example-modal-lg" onclick="MuestraModal('modal_filtros.php')" role="tab"><span class="hidden-sm-up"><span>Filtros</span></a>
								</li>
                                 <li aria-expanded="false" class="">
									<a class="nav-link"data-toggle="modal" data-target=".bs-example-modal-lg"  onclick="MuestraModal('modal_permisos.php')" role="tab"><span class="hidden-sm-up"><span>Permisos</span></a>								
								</li>
                                 <li aria-expanded="false" class="">
									<a  class="nav-link"data-toggle="modal" data-target=".bs-example-modal-lg"  onclick="MuestraModal('modal_parametros.php')" role="tab"><span class="hidden-sm-up"><span>Parametros</span></a>						
								</li>
                            </ul>
							
           
                    
						

						<div class="form-inline">							
							<div class="form-group m-r-15">
								<label  class="block form-control-label">Tipo de reporte</label>
								<?php imprimir($recordset["tipo_reporte"],"Tipo",20);	?>
							</div>	
							<div class="form-group m-r-15">
								<label  class="block form-control-label">Nombre del Reporte</label>
								<?php imprimir($recordset["nombre_reporte"],"Nombre del reporte",40);	?>
							</div>	
						<div class="form-inline">
							<div class="form-group m-r-15">
								<label  class="block form-control-label">Tabla</label>
								<?php imprimir($recordset["tabla"],"Tabla",20);	?>
							</div>	
								<div class="form-group m-r-15">
								<label  class="block form-control-label">Identificador</label>
								<?php imprimir($recordset["identificador"],"Identificador",20);	?>
							</div>	
	
							<div class="form-group m-r-15">
								<label  class="block form-control-label">Orden</label>
								<?php imprimir($recordset["orden"],"Orden",20);	?>
							</div>
						<!-- para checkbox	-->

						<!--	-->							
						</div>
							<div class="form-group m-r-15">
								<label  class="block form-control-label">SQL Query</label>
								<?php  imprimir($recordset["sqlquery"],15,40,30);	?>
							</div>	

							<div class="form-group m-r-15">
								<label  class="block form-control-label">Condicion (Where 1 por default)</label>
								<?php imprimir($recordset["condicion"],10,20,6);	?>
							</div>		

							<div class="form-group m-r-15">
								<label  class="block form-control-label">Notas del Reporte</label>
								<?php  imprimir($recordset["sugerencia"],10,20,6);	?>
							</div>	
						</div>
                    
                        </div>
                    </div>
                </div>
            <?php
} // fin plantilla

?>

		<div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <!-- sample modal content -->
                                <div class="modal bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger waves-effect text-left" data-dismiss="modal">Cerrar</button>
                                            </div>
<iframe name='modal-frame' src='' style='border: 1' width='100%' height='400px' frameborder='1' scrolling='yes'></iframe>

                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- /.modal -->
                                
                            </div>
                        </div>
                    </div>
							

<script>
	function myFunction2() {
	document.getElementById("botonfiltro").click()
	}
</script>

<script>
<?php echo $JavaScript; ?>
</script>
  <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <script src="dist/js/app.min.js"></script>
    <script src="dist/js/app.init.js"></script>
    <script src="dist/js/app-style-switcher.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
   <script src="dist/js/feather.min.js"></script>
    <script src="dist/js/custom.min.js"></script>
	
</body>
</html>