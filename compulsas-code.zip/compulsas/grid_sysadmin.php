<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

<body>
<?php   
try {
  $dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
}
catch(PDOException $e) {
  die('pdo connection error: ' . $e->getMessage());
}

if(!isset($_SESSION['Filtro_Reporte'])) $_SESSION['Filtro_Reporte']=0;
if (isset($_POST["reporte_tipo1"])) {
			if($_SESSION['Filtro_Reporte']!=$_POST["reporte_tipo1"]) {
				$_SESSION['Filtro_Reporte']=$_POST["reporte_tipo1"];
			}
			$consulta="Select * from reporte where id_reporte=".$_SESSION['Filtro_Reporte'];
	//		echo $consulta;
			
			$recordset=$dbh->query($consulta);
			
				$reporte=$recordset->fetch();
		//	var_dump($reporte);

				$t_query=$reporte["sqlquery"];
				$_SESSION['var_sql_Tiporeporte']=$reporte["tipo_reporte"];
				$_SESSION['var_sql_sugerencia']=$reporte['sugerencia'];
				$t_tabla=$reporte["tabla"];
				$_SESSION['var_sql_fase']=$reporte["fase"];
				
				$_SESSION['var_sql_nombrereporte']=$reporte["nombre_reporte"];				
				$t_condicion=$reporte["condicion"];
				$t_campo_busca=$reporte["campo_busca"];
				$t_idtabla=$reporte["identificador"];
				$t_titulo=$reporte["titulo_grid"];
				
				$_SESSION['var_sql_orden']=$reporte["orden"];
				$_SESSION['var_sql_grupo']=$reporte["grupo"];
				
		
				$_SESSION['var_sql_query']=$t_query;
				$_SESSION['var_sql_tabla']=$t_tabla;
				$_SESSION['var_sql_id']=$t_idtabla;
				$_SESSION['var_sql_condicion']=$t_condicion;

    }   
	


switch ($_SESSION['var_sql_Tiporeporte']) {
case 'CAT':
	$retorno='catalogos.php';
	break;
case 'SYS':
	$retorno='catalogos_grid.php';
	break;	
case 'BDD':
	$retorno='reportes.php';
	break;
case 'RH':
	$retorno='reportes_rh.php';
	break;	
case 'AUDIT':
	$retorno='reportes_auditoria.php';
	break;	
case 'OFICIALIA':
	$retorno='reportes_oficialia.php';
	break;		
case 'COMPULSAS':
	$retorno='reportes.php';

	break;		
default:
	$retorno='reportes.php';
}	

?>
<table  class="table table-striped table-sm">
  <tr>
    <th scope="row"> <?php echo $_SESSION['var_sql_nombrereporte'] ?></th>
    <td width="11%" scope="row"><a class='btn btn-warning' href="<?php echo $retorno;?>" title="Otros reportes"><strong>Otros Reportes</strong></a></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="3" class="bordered">
  <tr>
    <td scope="row"><?php echo $_SESSION['var_sql_sugerencia']?></td>
    </tr>
</table>
<?php 
											
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		$lm = new lazy_mofo($dbh); 

		// table name for updates, inserts and deletes
		$lm->table = $_SESSION['var_sql_tabla'];
		
		$lm->primary_form=false; // Indicamos que no es un formulario principal
		
		
	$condicion="";
//***************************** CODIGO DE AUTOFILTROS **********************************	/
$formulario = basename($_SERVER['PHP_SELF']); // Parametro 1: El nombre del formulario, para que al limpiar filtros, regrese al formulario correcto
include ("codigo_filtros.php"); // aqu� inclu�mos el archivo php que tiene la funci�n. 
$Where_paginas = barrafiltros($formulario,$_SESSION['Filtro_Reporte']);
$condicion = $Where_paginas['Filtro'];
$JavaScript= $Where_paginas['JS'];

// generamos el where para obtener los filtros solicitados en la barra de filtros
//***************************** *******************************************************	/
//***************************** *******************************************************	/
		
		
$lm->date_out = 'Y-m-d';  //Para editar se requieren el "guion medio"	
	$lm->date_in = 'Y-m-d';	


$lm->grid_output_control['adjunto'] = '--document'; // image clickable  
	$lm->upload_path="oficialia";	
//***************************** *******************************************************	/
		 $lm->return_to_edit_after_insert = false;
	 $lm->return_to_edit_after_update = false;
		// identity / primary key for table
		$lm->identity_name = $_SESSION['var_sql_id'];
	//	$lm->identity_name = 'id_cat_servicios';

		$order_by="";
		if ($_SESSION['var_sql_orden'] <> NULL) $order_by = "  order by ".$_SESSION['var_sql_orden'];
 $query_reporte= $_SESSION['var_sql_query']." ".$_SESSION['var_sql_condicion']."  $condicion  ".$_SESSION['var_sql_grupo'].$order_by;
 		
		$lm->grid_sql = $query_reporte;
		
	$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name];
	//	$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO

	
	//	echo $lm->grid_sql;
		$lm->run();
		

?>							
								
 
<script>
	function myFunction2() {
	document.getElementById("botonfiltro").click()
	}
</script>

                <script>
                    <?php echo $JavaScript; ?>
                </script>
				

    </body>

    </html>