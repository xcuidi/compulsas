<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
<body>
<div class="card-header">
                <h5 class="card-title">AVISOS DE LA PLATAFORMA</h5>
</div>
	<?php
 
		  

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
	//	$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'aviso';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id_aviso';



$lm->grid_area_cols_size=60;
$lm->grid_area_rows_size=15;
		
		// optional, make friendly names for fields
		
	//	$lm->rename['usuario_activo'] = 'Activo';
		//$lm->rename['fechanacimiento'] = 'Fecha';
		
$lm->form_input_control['adjunto'] = '--document';
$lm->grid_output_control['adjunto'] = '--document'; // image clickable  
		
$lm->date_out = 'Y-m-d';  //Para editar se requieren el "guion medio"	
	$lm->date_in = 'Y-m-d';		
	
		$lm->grid_limit = 20;  
		// optional, define editable input controls on the grid
		
////BUSQUEDAS



$lm->upload_path="uploads";

	$lm->form_input_control['activo'] = '--checkbox';	
	$lm->form_input_control['visible_para'] = "SELECT
  usuario.id_estructura,
  usuario.nombre
FROM
  usuario; --selectmultiple";	
	$lm->grid_output_control['link'] = '--link';
	
	

//***************************** CODIGO DE AUTOFILTROS **********************************	/
		$formulario = basename($_SERVER['PHP_SELF']);
		include("codigo_filtros.php");	
		$Where_filtros=barrafiltros($formulario,0);	
		$condicion=$Where_filtros['Filtro'];
		$JavaScript= $Where_filtros['JS'];
		
			//REGRESA ARREGLO CON 2 VARIABLES: Search_Box Y Filtro
//***************************** *******************************************************	/	
$query_aviso="Select
    aviso.fecha,
    aviso.encabezado,
    aviso.txt_aviso,
    aviso.aviso_para,
    aviso.fecha_vigencia,
    aviso.adjunto,
    aviso.link,
    aviso.id_usuario,
    aviso.id_aviso
From
    aviso
  where 1
  $condicion 
  order by 
  aviso.id_aviso desc";
		
		
		$lm->grid_sql = $query_aviso;

$lm->on_insert_validate['fecha'] = array('/.+/', 'Dato requerido', 'Requerido'); 
$lm->on_insert_validate['txt_aviso'] = array('/.+/', 'Dato requerido', 'Requerido'); 
$lm->on_insert_validate['fecha_vigencia'] = array('/.+/', 'Dato requerido', 'Requerido'); 
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	//	$lm->form_default_value['condicion']=array(' where 1' );
		
		
		// use the lm controller
		$lm->run();
//}
	
								
								

?>
	
</body>
</html>