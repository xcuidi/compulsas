<?php
include ('utilerias/connect.php');
 date_default_timezone_set('UTC');
date_default_timezone_set("America/Mexico_City");

$usuario = $_POST['usuario_ua'];
$clave = $_POST['clave_ua'];



//$sql = "SELECT * FROM admin WHERE admin_username = ? AND password = ?";
$sql = "Select
    usuario.nombre,
    usuario.usuario,
    usuario.clave,
    usuario.correo,
    usuario.foto,
    tipo_usuario.descrip,
    grupo.nombre_grupo,
    usuario.id_tipo_usuario,
    usuario.id_usuario,
    tipo_usuario.id_mnu,
    tipo_usuario.id_grupo
From
    usuario Inner Join
    tipo_usuario On tipo_usuario.id_tipo_usuario = usuario.id_tipo_usuario Inner Join
    grupo On grupo.id_grupo = tipo_usuario.id_grupo
Where
    usuario.usuario = :usuario And
    usuario.clave = :clave And
    usuario.usuario_activo = 1";



	$query = $conn->prepare($sql);
	$query->execute(array(':usuario' => $usuario, ':clave' => $clave));



$row = $query->fetch();
$count = $query->rowCount();

//var_dump($row);
if ($count == 1){
			session_start(); 
 	

	     	 $_SESSION['Nombre_Usuario']=$row['nombre'];  // asignamos el nombre del usuario que entro..
	     	 $_SESSION['Usuario']=$usuario;  // asignamos el nombre del usuario que entro..
		 	 $_SESSION['SesIdUsuario']=$row['id_usuario'];  // asignamos el nombre del usuario que entro..
		 	// $_SESSION['SesTipoUs']=$row['id_tipousuario'];  // asignamos el nombre del usuario que entro..
		 	 $_SESSION['SesMnu']=$row['id_mnu'];  // asignamos el nombre del usuario que entro..
			
			 $_SESSION['SesIdTipo']=$row['id_tipo_usuario'];
			  $_SESSION['SesTipo']=$row['descrip'];
		 	 $_SESSION['SesPermisos']="";  // asignamos el nombre del usuario que entro..

			  $_SESSION['SesGrupo']=$row['id_grupo'];	
	
			   $_SESSION['SesNombreGrupo']=$row['nombre_grupo'];
			   $_SESSION['SesFoto']=$row['foto']; 
			   if($_SESSION['SesFoto'] == NULL) $_SESSION['SesFoto']="unnamed.jpg";
//----
			//   $ipvisita=getRealIP();

			//	$query_bitacora="insert into bitacora (id_bitacora, movimiento, fecha, id_usuario,ip_visita) values (0,'login',now(),".$_SESSION['SesIdUsuario'].",'".$ipvisita."')";

			$ahora = date("Y-m-d H:i:s"); 
			$query_bitacora="insert into bitacora (id_bitacora, movimiento, fecha, id_usuario) values (0,'login','$ahora',".$_SESSION['SesIdUsuario'].")";

	$query = $conn->prepare($query_bitacora);
	$query->execute();

			
	echo 1;
}else{
	
	echo 0;
}
?>

 