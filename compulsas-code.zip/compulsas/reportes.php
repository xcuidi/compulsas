<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>


    <body>
<h4>Reportes</h4>

<?php
try {
  $dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
}
catch(PDOException $e) {
  die('pdo connection error: ' . $e->getMessage());
}




// create LM object, pass in PDO connection
$lm = new lazy_mofo($dbh); 

function llenarcombo($query="",$valor=0,$descrip="") {
  global $dbh;
  $combo="<option value=0>Buscar..</option>";
   foreach($dbh->query($query) as $row) {
    $combo.= "<option value=".$row[$valor].">".$row[$descrip]."</option>";
      }
    return $combo;
}

?>
<table style='width: 100%;' id='example_x' class='table table-hover table-striped table-bordered'>
  <tr>
    <th colspan="2">REPORTES</th>
  </tr>
  <tr>
    <td width="19%">Seleccione un reporte </td>
  
    <td width="81%">
      <form action="grid_sysadmin.php"  id="miformulario3" method="post">
      <select value='' name="reporte_tipo1" id="reporte_tipo1" class='lm_search_input' placeholder='Seleccionar'> <?php
          print llenarcombo("select id_reporte, nombre_reporte from reporte where tipo_reporte='COMPULSAS'","id_reporte","nombre_reporte"); ?>  </select>
      <input name="submit172" type="submit" value="Mostrar" />
      </form>    </td>
  </tr>
</table>

</body>
</html>