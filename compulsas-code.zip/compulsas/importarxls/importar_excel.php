<?php
include('../utilerias/connect.php');

include 'src/SimpleXLSX.php';
session_start();  
$id_tabla = key_exists('id_tabla', $_GET) ? $_GET['id_tabla'] : 0;


if (isset($id_tabla)) 
	if ($id_tabla>0) $_SESSION['Tempo_Tabla']=$id_tabla;
	
	$rs=$conn->query("select * from tablas_sefip where tablas_sefip.id=".$_SESSION['Tempo_Tabla']);

if ($id_tabla==0) {
	echo "<h2> No se ha definido el archivo a importar</h2>";
	exit;
	
}
$col_validacion=1; // siempre la columna 2, campo "UE" 
$registros_importados=0;
foreach ($rs as $row){
	$tabla=$row['nombre_tabla'];
	$campos=$row['campos'];
	
	$descripcion=$row['descripcion'];
	$sql_limpieza=$row['sql_limpieza'];
	$sql_update=$row['sql_update'];
	if ($row['col_validacion']>0) {
		$col_validacion=$row['col_validacion'];
		$dato_validacion=$row['valor_validacion'];
	}
}

$mostrar=false;
if (isset($_POST["import"]))

{
    $mostrar=true;
$allowedFileType = ['application/vnd.ms-excel','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  

  $campos=str_replace(" ","",$campos);

 // echo $campos."<br>";
  $array_campos=explode(',',$campos);
  $columnas=count($array_campos);
  $parametros="";
  $separador=",";
  for($i=1;$i<=$columnas;$i++) {
	  if ($i==$columnas) $separador="";
	  $parametros .= "?".$separador;
  }
	

 
   //$sqlSelect = "SELECT * FROM $tabla";
  
 // $conn->query("truncate $tabla");
  if(in_array($_FILES["file"]["type"],$allowedFileType)){

        $targetPath = 'subidas/'.$_FILES['file']['name'];
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
		$xlsx = new SimpleXLSX( $targetPath );
		$sql_insert="INSERT INTO $tabla ($campos) VALUES ($parametros)";

		$stmt = $conn->prepare($sql_insert);
		$i=1;
		
	$fila=1;
	foreach ($xlsx->rows() as $fields) {
	
		
		$x=0; //columnas
		$j=1; //NUM_col_param
		for ($x=0; $x<$columnas; $x++) {
		$campo[$x]=trim($fields[$x]);
		
		 $stmt->bindParam( $j, $campo[$x]);
			//echo $j."=".$campo[$x]." | ";
			//var_dump($campo[$x]);
			$j++;
		}
	  if (intval($campo[$col_validacion]) > 0) { //convertimos la columna de recibo a numero y comprobamos que sea mayor que 0
	  $error="";
		  try {
			 
			  $stmt->execute(); //x=row, empieza en la fila 9, pero cuenta desde el 0
			  $registros_importados++;
			  $id_ultimo=intval($conn->lastInsertId());
			  // completamos el sql update con el ultimo id insertado
			   if(strlen($sql_update)>10) $conn->query($sql_update.$id_ultimo) ;
		  } catch (Exception $e) {
			$error .= 'Excepción capturada: '.  $e->getMessage();
			//exit;
			}
		  
	  }
	  $fila++;
	}
    // if(strlen($sql_limpieza)>10) $conn->query($sql_limpieza) ;
	 echo "Se eliminaron encabezados y filas vacías";
  }
  else
  { 
        $type = "error";
        $message = "El archivo enviado es invalido. Por favor vuelva a intentarlo";
  }
  echo $error;
}
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" href="favicon.ico">
<title>Importar archivo </title>

<!-- Bootstrap core CSS -->
<link href="dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="assets/sticky-footer-navbar.css" rel="stylesheet">
<link href="assets/style.css" rel="stylesheet">

</head>

<body>
<header> 
  <!-- Fixed navbar -->
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark"> <a class="navbar-brand" href="#">Importar Datos</a>

  </nav>
</header>

<!-- Begin page content -->

<div class="container">
  <h3 class="mt-5">Importar archivo <?=$descripcion?></h3>
  <hr>
  <div class="row">
    <div class="col-12 col-md-12"> 
      <!-- Contenido -->
    
    <div class="outer-container">
        <form action="" method="post"
            name="frmExcelImport" id="frmExcelImport" enctype="multipart/form-data">
            <div>
                <label>Elija Archivo Excel</label> <input type="file" name="file"
                    id="file" accept=".xls,.xlsx">
                <button type="submit" id="submit" name="import"
                    class="btn-submit">Importar Registros</button>
        
            </div>
        
        </form>
        
    </div>
    <div id="response" class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>"><?php if(!empty($message)) { echo $message; } ?></div>
    
  <?php if ($mostrar==true)  
echo "<h3> Se importaron $registros_importados filas. </h3><br>Puede cerrar la ventana de importar datos"
 ?> 	
  <!-- Fin Contenido --> 
   
    </div>
  </div>
  <!-- Fin row --> 

  
</div>
<!-- Fin container -->
<footer class="footer">
  <div class="container"> <span class="text-muted">
    <p>_</p>
    </span> </div>
</footer>
<script src="assets/jquery-1.12.4-jquery.min.js"></script> 

<!-- Bootstrap core JavaScript
    ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 

<script src="dist/js/bootstrap.min.js"></script>
</body>
</html>