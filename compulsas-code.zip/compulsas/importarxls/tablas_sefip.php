<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('../utilerias/connect.php');
include('../utilerias/lazy_mofo.php');

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		

	
?>
   <!doctype html>
    <html lang="es">

    <head>
        <!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
     <![endif]-->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
        <link href="../assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../assets/css/main.css"


    </head>
<body>
<h4>Tablas de SEFIP para importar</h4>

	<?php
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=sapao_sefip;charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		// create LM object, pass in PDO connection
	//	$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		// table name for updates, inserts and deletes
		$lm->table = 'tablas_sefip';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = true;
		// identity / primary key for table
		$lm->identity_name = 'id';

		 $lm->grid_extra_link2 = "<a href=\"importar_excel.php?id_tabla=[identity_id]\" target=\"_blank\">[Importar]</a>";
$query_tablas="Select
    tablas_sefip.nombre_tabla,
    tablas_sefip.descripcion,
    tablas_sefip.id
From
    tablas_sefip";

$lm->grid_area_cols_size=40;
$lm->form_text_input_size=150;
$lm->grid_area_rows_size=5;


		
		// optional, define input controls on the form
		//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';
// optional, define editable input controls on the grid
		//$lm->form_input_control['is_active'] = "select 1, 'Yes' union select 0, 'No' union select 2, 'Maybe'; --radio";
			

		$lm->grid_sql = $query_tablas;
	
	//	echo $lm->grid_sql;
		$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
	
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	
		// use the lm controller
		$lm->run();
//}
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama�o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
global $lm;
$editable=true;
$nuevo_registro=true;
$activa='active';
if ($recordset["lm_accion"]!="Editar") $editable=false;

	$parametro=$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
	$_SESSION['Tempo_Tema']=$parametro;
 ?>
    <div class="card-block">
                <ul class="nav nav-tabs" role="tablist">
				
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#tab0" role="tab">Capacitacion</a>
                        <div class="slide"></div>
                    </li>
							
                    <li class="nav-item">
                        <button type="button" class="btn btn-default waves-effect" data-toggle="modal" data-target="#large-Modal">Diapositivas</button>
                        <div class="slide"></div>
                    </li>		
					
                </ul>  
                <div class="tab-content">
					<div class="tab-pane active" id="tab0" role="tabpanel">
						<div class="card-block">

							<div class="row">
							
								   <!--Horizontal Form starts-->
								   <div class="col-lg-6">


										<table>
										  <tr>
											<th colspan="2"><?php imprimir($recordset["lm_accion"],60);
													?></th>
										  </tr>
										  <tr>
											<td>Capacitación </td>
											<td><?php imprimir($recordset["id_capacitacion"],20);
													?></td>
										  </tr>
										  <tr>
											<td width="166">Nombre del tema </td>
											<td width="398"><?php imprimir($recordset["nombre_tema"],20);
													?></td>
										  </tr>
										  <tr>
											<td>Bloque/Menu</td>
											<td><?php imprimir($recordset["bloque"],80);
													?></td>
										  </tr>
										  <tr>
											<td>Es bloque separador</td>
											<td><?php imprimir($recordset["bloque_separador"],20);
													?></td>
										  </tr>										  
										  <tr>
											<td>Descripcion</td>
											<td><?php imprimir($recordset["descripcion"],80);
													?></td>
										  </tr>
										  <tr>
											<td>Orden</td>
											<td><?php imprimir($recordset["orden"],20);
													?></td>
										  </tr>
										</table>
									 </div>
								  
			  
							</div> <!--row-->	
						</div>
					</div>  

				</div>		
	</div>
				

<?php

} // fin plantilla
?>	



<script src="../bower_components/Jquery/dist/jquery.min.js"></script>
<script src="../bower_components/jquery-ui/jquery-ui.min.js"></script>
<script src="../bower_components/tether/dist/js/tether.min.js"></script>
<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
				
               
    </body>

    </html>