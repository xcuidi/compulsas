<?php


$servername = "127.0.0.1";

$username = "root";
$password = "";
$dbname="sapao_sefip";

$dbhost=$servername;
$dbuser=$username;
$dbpass=$password;

define('LM_HOSTNAME', $servername); // database host name
define('LM_USERNAME', $username);     // database user name
define('LM_PASSWORD', $password); // database password
define('LM_NAME', $dbname); // database name     
define('LM_TYPE', 'mysqli');  // database type
define('LM_CHARSET','utf8'); // ex: utf8(for mysql),AL32UTF8 (for oracle), leave blank to use the default charset


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
	 
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   //  echo "Connected successfully"; 
   
    }
catch(PDOException $e)
    {
     echo "Connection failed: " . $e->get/Message();
    }

?>