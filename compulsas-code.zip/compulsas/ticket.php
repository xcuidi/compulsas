<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');
	 date_default_timezone_set('UTC');
	date_default_timezone_set("America/Mexico_City");
	 $ahora = date("Y-m-d H:i:s"); 
?>

<!doctype html>
<html lang="es">

<head>
<!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
     <![endif]-->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/main.css">
<script type="text/javascript" src="bower_components/tether/dist/js/tether.min.js"></script>

</head>
<body>


		

<form method="post" action="<?=$_SERVER['PHP_SELF']?>" id="myForm" class="bordered">   
<table width="100%" border="0" cellspacing="3">
  <tr>
    <th scope="row">REGISTRO DE TICKETS PARA ATENCI&Oacute;N DE FALLAS, SUGERENCIAS Y DUDAS </th>
  </tr>
 
</table>
<br />
<br />
</form>
									
<?php 
//echo $_SESSION['SesPermisos'];
		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
	//		var_dump($dbh);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		global $lm;
		$lm = new lazy_mofo($dbh); 
		
		// create LM object, pass in PDO connection
		
		
		// table name for updates, inserts and deletes
		$lm->table = 'ticket';
		
		 $lm->return_to_edit_after_insert = false;
		 $lm->return_to_edit_after_update = false;
		// identity / primary key for table
		$lm->identity_name = 'id_ticket';
	//$lm->form_input_control['country_id'] = 'select country_id, country_name from country; --select';
		
		if(substr($_SESSION['SesPermisos'],1,1)!="1") $lm->puede_editar=false;		
		if(substr($_SESSION['SesPermisos'],2,1)!="1") $lm->puede_borrar=false;
		if(substr($_SESSION['SesPermisos'],6,1)!="1") $lm->puede_exportar=false;
		
		if ($_SESSION['SesGrupo']==1) $lm->puede_editar=true;	
		$lm->timezone='Mexico/General';
//		$lm->auto_populate_controls = false;
//			$lm->date_out = 'd/m/Y';	
		$lm->date_out = 'Y-m-d';  //Para editar se requieren el "guion medio"
		$lm->datetime_out = 'd/m/Y';  				
//		$lm->datetime_out = 'd/m/Y h:i A'; 	
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		$lm->grid_output_control['adjunto'] = '--image';
		$lm->grid_output_control['fecha'] = '--date';		
		$lm->form_input_control['adjunto'] = '--document';	
		$lm->grid_output_control['adjunto'] = '--document';	
		$lm->form_input_control['tutorial'] = '--checkbox';	
		
		$lm->grid_output_control['imagen2'] = '--image';
		$lm->grid_show_images=true;
		$lm->image_style = "style='height: 20px;'";
		$lm->rename['imagen'] = '_';
		$lm->thumb_path=".";
			
	//	$lm->grid_show_images = true;
		$lm->upload_path="../adjuntos";
		$lm->form_default_value['fecha']=$ahora;
		$lm->form_input_control['id_estatus_seg'] = "select id_estatus_seg, nombre_estatus_seg from estatus_seg where tipo='TICKET'; --select";
		$lm->form_input_control['clasificacion'] = "select id_estatus_seg, nombre_estatus_seg from estatus_seg where tipo='ERROR'; --select";		
		
		$lm->form_input_control['atendido_por'] = "select id_estatus_seg, nombre_estatus_seg from estatus_seg where tipo='ATENCION_TICKET'; --select";				
		$lm->form_input_control['fecha'] = '--solo_lectura';			
		
	////*********FUNCIONES DE VALIDACION
$lm->validate_text_general = "Faltan datos o hay valores incorrectos";
//$lm->on_insert_validate['clasificacion'] = array('/.+/', 'Falta  Clasificacion', 'Requerido'); 
$lm->on_insert_validate['problema'] = array('/.+/', 'Falta  Nombre', 'Requerido'); 
$lm->on_update_user_function= 'update_modificado';
$lm->after_insert_user_function = 'nuevo_registro'; // Esta funcion te da el Ultimo ID
$lm->on_update_validate = $lm->on_insert_validate;  
function update_modificado(){
		global $lm;	
	date_default_timezone_set('Mexico/General');
		$sql_param = array(':id_ticket' => $_POST['id_ticket']);
	$instruccion= "Se actualiz� el ticket: ".$_POST['id_ticket']." por el usuario ".$_SESSION['Nombre_Usuario'];
	$sql_bitacora="insert into bitacora (id_bitacora, movimiento, observaciones, fecha, id_usuario) values (0,'update_ticket','".$instruccion."',now(),".$_SESSION['SesIdUsuario'].")";				 
	$lm->query($sql_bitacora, $sql_param);		
	mayusculas();
	enviar_notificacion($_POST['id_ticket']);
}
function mayusculas() {
$_POST['problema']=strtoupper($_POST['problema']);
$_POST['respuesta']=strtoupper($_POST['respuesta']);
}
function enviar_notificacion($tmp_ticket) {
			  	 // En esta secci�n debe ir el aviso del correo electr�nico
//global 	$id;
global $lm;
	$sql_param = array(':id_ticket' => $tmp_ticket);
	$instruccion= "SELECT
  ticket.id_ticket,
  ticket.fecha,
  ticket.problema,
  ticket.id_usuario,
  Concat(matrimonio.nombre_el, ' - ', matrimonio.nombre_ella) AS Enviado_por,
  tipomat.rol AS Rol,
  matrimonio.correo_el AS Correo,
  ticket.mail_enviado,
  sector.nombre_sector,
  diocesis.bloque,
  diocesis.diocesis
FROM
  ticket
  INNER JOIN matrimonio ON ticket.id_usuario = matrimonio.id_matrimonio
  INNER JOIN sector ON matrimonio.id_sector = sector.id_sector
  INNER JOIN diocesis ON sector.id_diocesis = diocesis.id_diocesis
  INNER JOIN tipomat ON matrimonio.id_tipomat = tipomat.id_tipomat
WHERE
  ticket.mail_enviado = 0 AND
  ticket.id_ticket =".$tmp_ticket; 
		$registro=$lm->query($instruccion, $sql_param);
		
$cnbdr="SELECT
  matrimonio.correo_el,
  matrimonio.correo_ella
FROM
  matrimonio
  INNER JOIN sector ON sector.id_sector = matrimonio.id_sector
  INNER JOIN diocesis ON diocesis.id_diocesis = sector.id_diocesis
WHERE
  matrimonio.id_tipomat = 35 AND
  matrimonio.id_estatus_mat IN (20, 26) and diocesis.region=".$_SESSION['SesRegion'];	

	$correos_region=$lm->query($cnbdr);	
	$dest1=$correos_region[0]['correo_el'];
	$dest2=$correos_region[0]['correo_ella'];

	//	$cuantos=$registro->rowCount();
//$ultimo=$registro[0]['Last'];
  
						$t_ticket=$registro[0]['id_ticket'];
						$problema=$registro[0]['problema'];
						$t_rol=$registro[0]['Rol'];
						$t_bloque=$registro[0]['bloque'];
						$msj="Buen dia! <br>";
						$msj=$msj."El matrimonio formado por ".$registro[0]['Enviado_por']."  del sector ".$registro[0]['nombre_sector']." con Rol ".$t_rol.", de la diocesis de ".$registro[0]['diocesis']." ha reportado un problema <br> <br><br>Problema: ".$problema."<br>";
						$msj=$msj.="<br> Aviso automatico. <br><br>NO RESPONDER ESTE MENSAJE";

						$asunto="BLOQUE:".$t_bloque." TICKET MAT: ".$tmp_ticket." reportado por ".$registro[0]['Enviado_por'];		
 // echo $id_seguim,"<br>",$msj, "<br>",$asunto;
  					 //obteniendo nombre y correo de los supervisores					 
				 		
				//		$_SESSION['tempo_correo']=$cuantos ;	 
								$dest="ticketsmfc@gmail.com";
							$exito=0;
							if($t_ticket>0)	$exito=enviarmail($dest, $asunto, $msj);
								$replyto="";
								
								$exito1=false;
								$exito2=false;
								if(strlen($dest1)>=8) $exito1=enviarmail($dest1, $asunto, $msj);
								if(strlen($dest2)>=8) $exito2=enviarmail($dest2, $asunto, $msj);	
							if ($exito==1)								 						 
							 {						
									echo "<br> -enviado a ",$dest,"<br>";
									$sql_inserta="update ticket set mail_enviado=1 where ticket.id_ticket=".$tmp_ticket;
									$lm->query($sql_inserta, $sql_param);
									
							//		$lxcon_aux->query("update ticket set mail_enviado=1 where ticket.".$ticket->GetCampoID()."=".$t_ticket);
							 }
							 else
							 {
								echo " <br>-error enviando a",$dest,"<br>";
							 }	
///FIN DE CORREOS		
}
	function solo_lectura($column_name, $value, $command, $called_from){
	
		// $column_name: field name
		// $value: field value  
		// $command: full command as defined in the arrays: form_input_control, grid_input_control, or grid_output_control
		// $called_from: which function called this user function; form, or grid
	
		global $lm;
		$val = $lm->clean_out($value);
		return "<input type='text' name='$column_name' value='$val' readonly >";
	
	}	
function nuevo_registro($id){
	
	// after_insert_user_function is the only action to get the identity id
	// now that the record is added we can do anything we need to
	global $lm;
	$tmp_ticket=$id;
	$sql_inserta="update ticket set id_usuario=".$_SESSION['SesIdUsuario'].", tipo='M' where id_ticket=".$id;
	$lm->query($sql_inserta);
	
	 date_default_timezone_set('UTC');
	date_default_timezone_set("America/Mexico_City");
	 $ahora = date("Y-m-d H:i:s"); 
 
	$instruccion=str_replace("'","-",$sql_inserta);
	$sql_bitacora="insert into bitacora (id_bitacora, movimiento, observaciones, fecha, id_usuario) values (0,'Insert_Ticket','".$instruccion."','$ahora',".$_SESSION['SesIdUsuario'].")";				 
	$lm->query($sql_bitacora);

}

		$lm->grid_sql ="SELECT
		estatus_seg.imagen2,
  ticket.id_ticket AS Ticket,
    concat('Fecha: ',ticket.fecha,' | ',ticket.problema) AS Problema,
  estatus_seg.nombre_estatus_seg AS Clasificacion,
   concat('Fecha: ',ticket.fecha_respuesta,' | ',ticket.respuesta) AS Respuesta,
  ticket.adjunto,
  ticket.atendido_por,
  ticket.id_ticket
FROM
  ticket
  
  LEFT JOIN estatus_seg ON ticket.id_estatus_seg = estatus_seg.id_estatus_seg
 
WHERE 1";			

	
	//	$lm->grid_sql_param[':_search'] = '%' . trim(@$_REQUEST['_search']) . '%';
	//	$lm->grid_output_control['ruta'] = '--document';
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
		
		$lm->form_custom_template=true; // SE ESPECIFICA QUE HAY UNA PLANTILLA DEFINIDA PR EL USUARIO
		
		$lm->form_sql = "SELECT
  ticket.id_ticket,
  ticket.problema,
  ticket.fecha,
  ticket.respuesta,
  ticket.fecha_respuesta, clasificacion, etiquetas, id_estatus_seg,
  ticket.adjunto, atendido_por
FROM
  ticket
WHERE 
id_ticket = :id_ticket ";
		
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
		
		//$lm->form_default_value['id_matrimonio']=array($_SESSION['TEMPO_matrimonio']);
//		var_dump($_SESSION['tempo_correo']);
		
		// use the lm controller
		$lm->run();
	
  
function plantilla($recordset) { 
// USAR LA FUNCION:
//	imprimir(<nombre_control>,<tama�o_texto>,<cols_area>,<rows_area>) 
// para imprimir los controles en pantalla.
?> 
<table cellspacing="3" class="table table-bordered table-sm">
    <th colspan="4"><?php imprimir($recordset["lm_accion"],60);
			?></th>
  </tr>
  <tr>
    <td width="208">Fecha</td>
    <td colspan="3"><?php imprimir($recordset["fecha"],80);
			?></td>
  </tr>
  <tr>
    <td>Clasificaci&oacute;n del ticket</td>
    <td colspan="3"><?php imprimir($recordset["clasificacion"],20);
			?></td>
  </tr>
  <tr>
    <td>Descripcion del problema o sugerencia</td>
    <td colspan="3"><?php imprimir($recordset["problema"],0,60,5);
			?> </td>
  </tr>
  <tr>
    <td>Captura de pantalla</td>
    <td colspan="3"><?php imprimir($recordset["adjunto"],100);
			?>      De ser posible anexe una captura de pantalla.</td>
  </tr>
  <tr>
<?php if ($recordset["lm_accion"]!="Nuevo Registro") { ?>
    <td>Fecha de respuesta</td>
    <td colspan="3"><?php imprimir($recordset["fecha_respuesta"],60);
			?></td>
  </tr>
  <tr>
    <td>Respuesta</td>
    <td colspan="3"><?php imprimir($recordset["respuesta"],0,100,5);
			?></td>
  </tr>
  <tr>
    <td>Estatus</td>
    <td width="48"><?php imprimir($recordset["id_estatus_seg"],20);
			?></td>
    <td width="322">Atendido por</td>
    <td width="169"><?php imprimir($recordset["atendido_por"],20);
			?></td>
  </tr>
  <?php } ?>
</table>
  <br />

 <?php
} // fin plantilla

?>


</body>
</html>
