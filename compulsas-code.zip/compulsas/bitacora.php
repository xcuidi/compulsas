<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

    <body>
<div class="card-header">
                <h5 class="card-title">Bitacora del Sistema</h5>
</div>
	
     

									
									<?php 
									

                               

		try {
			$dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
		}
		catch(PDOException $e) {
			die('pdo connection error: ' . $e->getMessage());
		}
		
		// create LM object, pass in PDO connection
		$lm = new lazy_mofo($dbh); 
		
		
		// table name for updates, inserts and deletes
		$lm->table = "bitacora";
		
		 $lm->return_to_edit_after_insert = false;
	 $lm->return_to_edit_after_update = false;
		// identity / primary key for table
		$lm->identity_name = "id_bitacora";

		if(substr($_SESSION['SesPermisos'],0,1)!=1) $lm->puede_agregar=false;
		if(substr($_SESSION['SesPermisos'],1,1)!=1) $lm->puede_editar=false;		
		if(substr($_SESSION['SesPermisos'],2,1)!=1) $lm->puede_borrar=false;
		if(substr($_SESSION['SesPermisos'],6,1)!=1) $lm->puede_exportar=false;
		
		if($_SESSION['SesGrupo']==1) {
			$lm->puede_exportar=true;
			$lm->puede_borrar=true;
		}
		
//***************************** CODIGO DE AUTOFILTROS **********************************	/
		$formulario = basename($_SERVER['PHP_SELF']);
		include("codigo_filtros.php");	
		$Where_filtros=barrafiltros($formulario,0);	
		$condicion=$Where_filtros['Filtro'];
			//REGRESA ARREGLO CON 2 VARIABLES: Search_Box Y Filtro
//***************************** *******************************************************	/			
		

	
		$lm->date_out = 'd/m/Y';
			$lm->datetime_out = 'd/m/Y h:i A';  
		// optional, define editable input controls on the grid
		
			
		
		// optional, query for grid(). LAST COLUMN MUST BE THE IDENTITY for [edit] and [delete] links to appear
		$lm->grid_sql = "Select
    bitacora.movimiento,
    usuario.nombre,
    bitacora.fecha,
    bitacora.observaciones,
    bitacora.id_bitacora As Consec,
    usuario.id_usuario,
    bitacora.id_bitacora
From
    bitacora Inner Join
    usuario On usuario.id_usuario = bitacora.id_usuario
  where 1 $condicion 
ORDER BY
  bitacora.id_bitacora DESC";
 
		
		
		// optional, define what is displayed on edit form. identity id must be passed in also.  
	//	$lm->form_sql =  $_SESSION['var_sql_reporte'];
				
		$lm->form_sql_param[":$lm->identity_name"] = @$_REQUEST[$lm->identity_name]; 
		
	//	echo $lm->grid_sql;
		// use the lm controller
		$lm->run();
		
?>

    </body>

    </html>