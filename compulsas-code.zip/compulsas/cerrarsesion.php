<?php
 date_default_timezone_set('UTC');
date_default_timezone_set("America/Mexico_City");
	
	require("./utilerias/connect.php")	;

	session_start(); 
	 
	if (isset($_SESSION['SesIdUsuario'])) {
	$ahora = date("Y-m-d H:i:s"); 
	$cierre="insert into bitacora (id_bitacora, movimiento, fecha, id_usuario) values (0,'logout','$ahora',".$_SESSION['SesIdUsuario'].")";
	echo $cierre;
	$query = $conn->prepare($cierre);
	$result= $query->execute();
}
	
session_destroy();
header("Location: ./"); 
?>
