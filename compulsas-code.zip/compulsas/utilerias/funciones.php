<?php 
   
// Evaluar los datos que ingresa el usuario y eliminamos caracteres no deseados.
function evaluar($valor) 
{
	$nopermitido = array("'",'\\','<','>',"\"");
	$valor = str_replace($nopermitido, "", $valor);
	return $valor;
}

// Formatear una fecha a microtime para añadir al evento, tipo 1401517498985.
function _formatear($fecha)
{
	return strtotime(substr($fecha, 0, 4)."-".substr($fecha, 5, 2)."-".substr($fecha, 8, 2)." " .substr($fecha, 10, 6)) * 1000;
//		return strtotime(substr($fecha, 6, 4)."-".substr($fecha, 3, 2)."-".substr($fecha, 0, 2)." " .substr($fecha, 10, 6)) * 1000;

}

function enviarmail($to, $subject, $message, $replyto){
		
	
		//path to PHPMailer class
	require_once'./PHPMailer/PHPMailerAutoload.php';
	
	//echo (extension_loaded('openssl')?'SSL loaded':'SSL not loaded')."\n";
	
	//Create a new PHPMailer instance
	$mail = new PHPMailer;
	//Tell PHPMailer to use SMTP
	$mail->isSMTP(2);
	//Enable SMTP debugging
	// 0 = off (for production use)
	// 1 = client messages
	// 2 = client and server messages
	$mail->Mailer = "SMTP";
	$mail->SMTPDebug = 0;
	//Ask for HTML-friendly debug output
	$mail->Debugoutput = 'html';
	//Set the hostname of the mail server
//	$mail->Host = "mx1.hostinger.mx";
	$mail->Host = "mx1.hostinger.mx"; //s132-148-145-246.secureserver.net
	//Set the SMTP port number - likely to be 25, 465 or 587
	//
	$mail->Port = 587;
		// sets the prefix to the servier
		$mail->SMTPSecure = "tls";
	//Whether to use SMTP authentication
	$mail->SMTPAuth = true;
	//Username to use for SMTP authentication
//	$mail->Username = "notificaciones@SCTG-oaxaca.org";
	$mail->Username = "notificaciones@contraloriaoaxaca.net";
	
	//Password to use for SMTP authentication
	$mail->Password = "N0t1f1c4c10n3s";
	//Set who the message is to be sent from
//	$mail->setFrom('notificaciones@mfc-oaxaca.org','Notificacion automatica');
	$mail->setFrom('notificaciones@contraloriaoaxaca.net','Notificacion automatica');	
	//Set an alternative reply-to address
	if(strlen($replyto)>=8)
		$mail->addReplyTo($replyto, $replyto);
	else
//		$mail->addReplyTo('notificaciones@mfc-oaxaca.org','No responder este mensaje');
		$mail->addReplyTo('notificaciones@contraloriaoaxaca.net','');		
	//Set who the message is to be sent to
	$mail->addAddress($to, '');
	//Set the subject line
	$mail->Subject = $subject;
	//Read an HTML message body from an external file, convert referenced images to embedded,
	//convert HTML into a basic plain-text alternative body
	$mail->msgHTML($message);
	//Replace the plain text body with one created manually
	//$mail->AltBody = 'This is a plain-text message body';
	//Attach an image file
	//$mail->addAttachment('images/phpmailer_mini.png');
	$mail->CharSet = "UTF-8";
	//send the message, check for errors
	$exito = $mail->Send();
	
	//Si el mensaje no ha podido ser enviado se realizaran 4 intentos mas como mucho 
	//para intentar enviar el mensaje, cada intento se hara 5 segundos despues 
	//del anterior, para ello se usa la funcion sleep	
	$intentos=1; 
	while ((!$exito) && ($intentos < 2)) {
		sleep(1);
		echo $mail->ErrorInfo;
		$exito = $mail->Send();
		$intentos=$intentos+1;	
	}
//	echo $exito;
	return $exito;
}

function getRealIP()
{

    if (isset($_SERVER["HTTP_CLIENT_IP"]))
    {
        return $_SERVER["HTTP_CLIENT_IP"];
    }
    elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"]))
    {
        return $_SERVER["HTTP_X_FORWARDED_FOR"];
    }
    elseif (isset($_SERVER["HTTP_X_FORWARDED"]))
    {
        return $_SERVER["HTTP_X_FORWARDED"];
    }
    elseif (isset($_SERVER["HTTP_FORWARDED_FOR"]))
    {
        return $_SERVER["HTTP_FORWARDED_FOR"];
    }
    elseif (isset($_SERVER["HTTP_FORWARDED"]))
    {
        return $_SERVER["HTTP_FORWARDED"];
    }
    else
    {
        return $_SERVER["REMOTE_ADDR"];
    }

}

function fecha_texto($mifecha,$tipofecha="dmy",$letras="min"){
//tipos:
// dmy = 00 de nombremes de 0000
//dm = 00 de nombremes
//dmy2 00 de nombremes del año letrasdeaño
//min Minusculas
//may Mayusculas
$date=date_create($mifecha);
$dia = date_format($date,"d");
//if ($dia<10) $dia='0'.$dia;
$mes= date_format($date,"m");
$anio=date_format($date,"Y");
switch ($mes) {

case 1:
	$nombremes='enero';
	break;
	case 2:
	$nombremes='febrero';
	break;
	case 3:
	$nombremes='marzo';
	break;
	case 4:
	$nombremes='abril';
	break;
	case 5:
	$nombremes='mayo';
	break;
	case 6:
	$nombremes='junio';
	break;
	case 7:
	$nombremes='julio';
	break;
	case 8:
	$nombremes='agosto';
	break;
	case 9:
	$nombremes='septiembre';
	break;
	case 10:
	$nombremes='octubre';
	break;
	case 11:
	$nombremes='noviembre';
	break;
	case 12:
	$nombremes='diciembre';
	break;
}
switch ($tipofecha) {
	case 'dmy':
	$texto=$dia." de ".$nombremes." de ".$anio;
	break;
case 'dm':
	$texto=$dia." de ".$nombremes;
	break;
case 'dmy2':
	$texto=$dia." de ".$nombremes." del  año ".NumeroALetras::convertir($anio);
	break;
case 'dmy3':
	$texto = NumeroALetras::convertir($dia)." dias del mes de ".$nombremes." del  anio ".NumeroALetras::convertir($anio);
	break;	
}
if ($letras=='min')
	return strtolower($texto);
else
return strtoupper($texto);
}

function calculaedad($fechanacimiento){
	list($ano,$mes,$dia) = explode("-",$fechanacimiento);
	$ano_diferencia  = date("Y") - $ano;
	$mes_diferencia = date("m") - $mes;
	$dia_diferencia   = date("d") - $dia;
	if ($dia_diferencia < 0 || $mes_diferencia < 0)
		$ano_diferencia--;
	return $ano_diferencia;
}
function fnCreaSQLUpdate($lista_campos,$tabla,$lcVal){}
function fnCreaSQLWhere($lista_campos,$tabla){}

//--
function sanear_string($string)
{
 
    $string = trim($string);
 
    $string = str_replace(
        array('á', 'à', 'ä', 'â', 'ª', 'Á', 'À', 'Â', 'Ä'),
        array('a', 'a', 'a', 'a', 'a', 'A', 'A', 'A', 'A'),
        $string
    );
 
    $string = str_replace(
        array('é', 'è', 'ë', 'ê', 'É', 'È', 'Ê', 'Ë'),
        array('e', 'e', 'e', 'e', 'E', 'E', 'E', 'E'),
        $string
    );
 
    $string = str_replace(
        array('í', 'ì', 'ï', 'î', 'Í', 'Ì', 'Ï', 'Î'),
        array('i', 'i', 'i', 'i', 'I', 'I', 'I', 'I'),
        $string
    );
 
    $string = str_replace(
        array('ó', 'ò', 'ö', 'ô', 'Ó', 'Ò', 'Ö', 'Ô'),
        array('o', 'o', 'o', 'o', 'O', 'O', 'O', 'O'),
        $string
    );
 
    $string = str_replace(
        array('ú', 'ù', 'ü', 'û', 'Ú', 'Ù', 'Û', 'Ü'),
        array('u', 'u', 'u', 'u', 'U', 'U', 'U', 'U'),
        $string
    );
 
    $string = str_replace(
        array('ñ', 'Ñ', 'ç', 'Ç'),
        array('n', 'N', 'c', 'C',),
        $string
    );
 
    //Esta parte se encarga de eliminar cualquier caracter extraño

 
 
    return $string;
}


/**

 * easy image resize function

 * @param  $string - The image data, as a string

 * @param  $width - new image width

 * @param  $height - new image height

 * @param  $proportional - keep image proportional, default is no

 * @param  $quality - enter 1-100 (100 is best quality) default is 100

 */

  function resize_image($string             = null,

                              $width              = 0, 

                              $height             = 0, 

                              $proportional       = true, 

                            $quality = 100

  		 ) {

      

    if ( $height <= 0 && $width <= 0 ) return false;

    if ( $string === null ) return false;

    print $string;

    $string = base64_decode($string);



    # Setting defaults and meta

    $info                         = getimagesizefromstring($string);

    $image                        = '';

    $final_width                  = 0;

    $final_height                 = 0;

    list($width_old, $height_old) = $info;

	$cropHeight = $cropWidth = 0;



    # Calculating proportionality

    if ($proportional) {

      if      ($width  == 0)  $factor = $height/$height_old;

      elseif  ($height == 0)  $factor = $width/$width_old;

      else                    $factor = min( $width / $width_old, $height / $height_old );



      $final_width  = round( $width_old * $factor );

      $final_height = round( $height_old * $factor );

    }

    else {

      $final_width = ( $width <= 0 ) ? $width_old : $width;

      $final_height = ( $height <= 0 ) ? $height_old : $height;

	  $widthX = $width_old / $width;

	  $heightX = $height_old / $height;

	  

	  $x = min($widthX, $heightX);

	  $cropWidth = ($width_old - $width * $x) / 2;

	  $cropHeight = ($height_old - $height * $x) / 2;

    }



    # Loading image to memory according to type

    switch ( $info[2] ) {

      case IMAGETYPE_JPEG:  $image = imagecreatefromstring($string);  break;

      case IMAGETYPE_GIF:   $image = imagecreatefromstring($string);  break;

      case IMAGETYPE_PNG:   $image = imagecreatefromstring($string);  break;

      default: return false;

    }

    

    

    # This is the resizing/resampling/transparency-preserving magic

    $image_resized = imagecreatetruecolor( $final_width, $final_height );

    if ( ($info[2] == IMAGETYPE_GIF) || ($info[2] == IMAGETYPE_PNG) ) {

      $transparency = imagecolortransparent($image);

      $palletsize = imagecolorstotal($image);



      if ($transparency >= 0 && $transparency < $palletsize) {

        $transparent_color  = imagecolorsforindex($image, $transparency);

        $transparency       = imagecolorallocate($image_resized, $transparent_color['red'], $transparent_color['green'], $transparent_color['blue']);

        imagefill($image_resized, 0, 0, $transparency);

        imagecolortransparent($image_resized, $transparency);

      }

      elseif ($info[2] == IMAGETYPE_PNG) {

        imagealphablending($image_resized, false);

        $color = imagecolorallocatealpha($image_resized, 0, 0, 0, 127);

        imagefill($image_resized, 0, 0, $color);

        imagesavealpha($image_resized, true);

      }

    }

    imagecopyresampled($image_resized, $image, 0, 0, $cropWidth, $cropHeight, $final_width, $final_height, $width_old - 2 * $cropWidth, $height_old - 2 * $cropHeight);

    $quality = 9 - (int)((0.9*$quality)/10.0);

    ob_start();

    imagejpeg($image_resized);

    $output =  ob_get_contents();

    ob_end_clean();

    return base64_encode($output);

  }
  

  function arboldeEstructura($conn, $parent = 0, $spacing = '', $user_tree_array = '') 
  {
    if (!is_array($user_tree_array))
    $user_tree_array = array();
 
 //	$query = $conn->prepare($Sql);
//	$query->execute();	
//		$row = $query->fetch();
//		$count = $query->rowCount();
		
    $sql = "SELECT `id_estructura`, `nombre_puesto`, `id_nivelsuperior` FROM `estructura` WHERE 1 AND `id_nivelsuperior` = $parent ORDER BY id_estructura ASC";
    $query = $conn->prepare($sql);
    $query->execute();
    $total = $query->rowCount();
 
    if ($total > 0) 
    {
      while ($row = $query->fetch(PDO::FETCH_OBJ)) 
      {
        $user_tree_array[] = array("id_estructura" => $row->id_estructura, "name_puesto" => $spacing . $row->nombre_puesto);
        $user_tree_array = arboldeEstructura($conn,$row->id_estructura, $spacing . '&nbsp;&nbsp;', $user_tree_array);
      }
    }
    return $user_tree_array;
  }


  function arboldeEstructuraLista($conn, $parent = 0, $user_tree_array = '') 
  {
    if (!is_array($user_tree_array))
    $user_tree_array = array();
 	$tabla=array(4);
 //   $sql = "SELECT `id_categoria`, `nombre`, `id_padre` FROM `categorias` WHERE 1 AND `id_padre` = $parent ORDER BY id_categoria ASC";
    $sql = "SELECT id_estructura, nombre_puesto, id_nivelsuperior FROM estructura WHERE 1 AND id_nivelsuperior = $parent ORDER BY id_estructura ASC";
    $query = $conn->prepare($sql);
    $query->execute();
    $total = $query->rowCount();
 
    if ($total > 0) 
    {
      $user_tree_array[] = "<ul>";
	 
      while ($row = $query->fetch(PDO::FETCH_OBJ)) 
      {
	//  $nivel++;
	//  $nombre_superior=$row->nombre_puesto;
        $user_tree_array[] = "<li> ". $row->nombre_puesto."</li>";
        $user_tree_array = arboldeEstructuraLista($conn,$row->id_estructura, $user_tree_array);
      }
      $user_tree_array[] = "</ul>";
    }
    return $user_tree_array;
  }

 
  
  function superior($conn, $id_estructura=0, $nivel=0) {
  	 $sql_A = "SELECT id_estructura, nombre_puesto, id_nivelsuperior, 
	 nivel_estructura,
	 (select nivel_estructura from estructura E2 where E2.id_estructura=E1.id_nivelsuperior) as siguiente_nivel,
	 (select nombre_puesto from estructura E2 where E2.id_estructura=E1.id_nivelsuperior) as puesto_superior
	 FROM estructura E1 WHERE 1 AND id_estructura = $id_estructura ORDER BY id_estructura ASC";
    $query = $conn->prepare($sql_A);
    $query->execute();
    $total = $query->rowCount();
 	$dato=array();
    if ($total > 0) 
    {
	
	 $row2 = $query->fetch(PDO::FETCH_OBJ);
      
	
	  $dato['id']=$row2->id_estructura;
	  $dato['nivel_actual']=$row2->nivel_estructura;
	  $dato['siguiente_nivel']=$row2->siguiente_nivel;
	  $dato['id_superior']=$row2->id_nivelsuperior;
	  $dato['puesto_actual']=$row2->nombre_puesto;
	   $dato['puesto_superior']=$row2->puesto_superior;
	
    
	}
	return $dato;
  }
    
?>