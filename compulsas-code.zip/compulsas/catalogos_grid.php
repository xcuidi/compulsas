<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>

    <body>
        <h4>Catalogos del Sistema</h4>
        <?php
try {
  $dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
}
catch(PDOException $e) {
  die('pdo connection error: ' . $e->getMessage());
}

// create LM object, pass in PDO connection
$lm = new lazy_mofo($dbh); 

function llenarcombo($query="",$valor=0,$descrip="") {
  global $dbh;
  $combo="<option value=0>Buscar..</option>";
   foreach($dbh->query($query) as $row) {
    $combo.= "<option value=".$row[$valor].">".$row[$descrip]."</option>";
      }
    return $combo;
}

?>
            <div class="row">
                <div class="col-lg-6">

                    <div class="card">
                        <div class="card-block">
                            <form action="grid_sysadmin.php" id="miformulario3" method="post">

                                <div class="form-group">
                                    <label for="exampleSelect1" class="form-control-label">Seleccione un catalogo</label>
                                    <select class="form-control" value='' name="reporte_tipo1" id="reporte_tipo1" placeholder='Seleccionar'>
                                        <?php
          print llenarcombo("select id_reporte, nombre_reporte from reporte where tipo_reporte='SYS'","id_reporte","nombre_reporte"); ?>
                                    </select>

                                </div>
                                <div class="form-group">

                                    <button type="submit" class="btn btn-success waves-effect waves-light m-r-30">Mostrar</button>
                            </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
    </body>

    </html>