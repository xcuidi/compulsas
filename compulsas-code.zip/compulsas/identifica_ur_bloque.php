<?php
session_start();  
error_reporting(E_ALL);
// speed things up with gzip plus ob_start() is required for csv export
if(!ob_start('ob_gzhandler'))
	ob_start();
header('Content-Type: text/html; charset=utf-8');
include ('utilerias/connect.php');
include('utilerias/lazy_mofo.php');

// INCLUIMOS EL CODIGO DE CABECERA HTML
include('html_header.html');
// FIN DE CABECERA HTML
?>
		<!--SELECT 2 -->
		<link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/select2/css/s2-docs.css">
		<!--END SELECT 2 -->
<body>

<?php
try {
  $dbh = new PDO("mysql:host=".LM_HOSTNAME.";dbname=".LM_NAME.";charset=utf8", LM_USERNAME, LM_PASSWORD);
}
catch(PDOException $e) {
  die('pdo connection error: ' . $e->getMessage());
}




// create LM object, pass in PDO connection
$lm = new lazy_mofo($dbh); 

function llenarcombo($query="",$valor=0,$descrip="") {
  global $dbh;
  $combo="<option value=0>Buscar..</option>";
   foreach($dbh->query($query) as $row) {
    $combo.= "<option value=".$row[$valor].">".$row[$descrip]."</option>";
      }
    return $combo;
}

?>
 <form action="identificar_bloque.php"  id="miformulario3" method="get">
<table style='width: 100%;' id='example_x' class='table table-hover table-striped table-bordered'>
  <tr>
    <th colspan="2">Identificar Claves de Unidades responsables y Municipios </th>
  </tr>
  <tr>
    <td width="19%">Seleccione Entidad concentradora </td>
  
    <td width="81%">
     
      <select value='' name="entidad" id="entidad" class='lm_search_input' placeholder='Seleccionar'> <?php
          print llenarcombo("Select
    Replace(tabla_siox.razon_social, ' ', '*') As razon_social,
    Concat_Ws(' |', tabla_siox.razon_social, Count(tabla_siox.razon_social)) As registros
From
    tabla_siox
Where
    tabla_siox.id_ur Is Null
Group By
    tabla_siox.razon_social
Order By
    Count(tabla_siox.razon_social) Desc","razon_social","registros"); ?>  </select>
	
	</td>
	</tr>
	<tr>
	<td width="19%">Seleccione valor del catálogo </td>
 <td>
 <select class="js-example-placeholder-single" name="id_ur" id="id_ur">
  <?php
          print llenarcombo("Select
    catalogo_ur.id_ur,
    concat_ws('| ',catalogo_ur.clave_ur,
    catalogo_ur.nombre_ur,
    catalogo_ur.referencia) as Nombre
From
    catalogo_ur","id_ur","Nombre"); ?>  
</select>
  <input name="submit172" type="submit" value="Reemplazar" />
  </tr>
</table>
</form>
</body>
<script src="assets/libs/jquery/dist/jquery.min.js"></script>
	<!--SELECT 2 CSS / JS-->
	<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
	<script>
	$(document).ready(function() {
		$('.js-example-placeholder-single').select2({
		placeholder: "Buscar y seleccionar...",
		width: '50%',
   	 	allowClear: true });
	});
	</script>
	<!--END SELECT 2 CCS / JS-->
</html>